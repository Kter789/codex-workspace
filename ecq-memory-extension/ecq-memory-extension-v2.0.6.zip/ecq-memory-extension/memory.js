(() => {
  'use strict';

  const KIND_LABELS = {
    profile: '资料',
    preference: '偏好',
    project: '项目',
    todo: '待办 / 目标',
    decision: '决定',
    summary: '摘要',
    fact: '事实'
  };
  const STATUS_LABELS = {
    active: '有效',
    candidate: '待确认',
    archived: '已归档',
    superseded: '已被更新'
  };
  const SOURCE_LABELS = {
    explicit: '用户明确说',
    ai: '本地 AI 提炼',
    heuristic: '规则总结',
    mixed: 'AI + 规则',
    manual: '手动写入',
    summary: '对话摘要',
    imported: '导入',
    'promoted-machine': '本机提升',
    'migrated-v1': '旧版迁移'
  };
  const TURN_STATUS_LABELS = {
    requested: '等待回复',
    completed: '已回复',
    summarized: '已总结',
    summarizing: '总结中',
    'summary-failed': '总结失败',
    aborted: '已取消',
    abandoned: '已放弃',
    failed: '失败',
    disabled: '未总结'
  };
  const CONV_SUMMARY_LABELS = {
    pending: '待总结',
    running: '总结中',
    done: '已总结',
    failed: '总结失败',
    disabled: '未总结'
  };

  const $ = (id) => document.getElementById(id);

  let state = null;
  let stats = null;
  let scopeMode = 'acct';
  let view = 'memories';
  let conversationId = '';
  let knownAgents = new Map();
  let scopeChosen = false;
  let searchTimer = null;
  let listToken = 0;

  function uiMsg(type, payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, payload: payload || {} }, (resp) => {
          let err = null;
          try { err = chrome.runtime.lastError; } catch (_) {}
          if (err) resolve({ ok: false, reason: String(err.message || 'extension-error') });
          else resolve(resp || { ok: false, reason: 'empty-response' });
        });
      } catch (e) {
        resolve({ ok: false, reason: String((e && e.message) || 'send-failed') });
      }
    });
  }

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = String(text);
    return node;
  }

  function shortId(v, keep) {
    const s = String(v || '');
    const n = keep || 10;
    if (!s) return '—';
    if (s.length <= n + 4) return s;
    return s.slice(0, n) + '…' + s.slice(-4);
  }

  function fmtTime(ts) {
    const n = Number(ts) || 0;
    if (!n) return '—';
    const d = new Date(n);
    if (Number.isNaN(d.getTime())) return '—';
    try { return d.toLocaleString('zh-CN', { hour12: false }); } catch (_) { return d.toISOString(); }
  }

  function fmtBytes(n) {
    const v = Number(n) || 0;
    if (!v) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    let x = v;
    while (x >= 1024 && i < units.length - 1) { x /= 1024; i++; }
    return (x >= 10 ? x.toFixed(0) : x.toFixed(1)) + ' ' + units[i];
  }

  function fmtPct(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '—';
    return Math.round(n * 100) + '%';
  }

  function clipText(v, max) {
    const s = String(v || '');
    const n = max || 600;
    return s.length > n ? s.slice(0, n) + '…（已截断）' : s;
  }

  function setPill(node, text, tone) {
    node.textContent = text;
    node.className = 'pill' + (tone ? ' ' + tone : '');
  }

  function setStatus(text, isError) {
    const node = $('statusText');
    node.textContent = text || '';
    node.classList.toggle('error', !!isError);
  }

  function loggedIn() {
    return !!(state && state.identity && state.identity.loggedIn && state.identity.accountId);
  }

  function scopePayload() {
    return scopeMode === 'acct' ? { accountKnown: true } : { loggedOut: true };
  }

  function scopeLabel() {
    return scopeMode === 'acct' ? '账号记忆' : '本机记忆';
  }

  function scopeUsable() {
    if (scopeMode === 'acct' && !loggedIn()) {
      setStatus('账号记忆需要先登录 chat.echenqi.cn，再点「刷新登录态」。', true);
      return false;
    }
    return true;
  }

  function renderIdentity() {
    const ident = (state && state.identity) || {};
    const isLogged = loggedIn();
    const display = ident.name || ident.username || (isLogged ? '已登录账号' : '本机使用中');
    $('identityName').textContent = display;
    setPill($('scopePill'), isLogged ? '账号' : '本机', isLogged ? 'pill-acct' : 'pill-muted');
    const meta = [];
    if (isLogged) {
      if (ident.username && ident.username !== display) meta.push('账号 ' + ident.username);
      if (ident.role) meta.push('角色 ' + ident.role);
      meta.push('ID ' + shortId(ident.accountId));
    } else {
      meta.push('未登录 · 只读写这台电脑的本机记忆');
    }
    $('identityMeta').textContent = meta.join(' · ');
    $('accountIdText').textContent = isLogged ? shortId(ident.accountId) : '未登录';
    $('accountIdText').title = isLogged ? String(ident.accountId || '') : '';
    const machineId = String((state && state.machineId) || '');
    $('machineIdText').textContent = shortId(machineId);
    $('machineIdText').title = machineId;
    const ns = isLogged
      ? 'acct:' + shortId(ident.accountId, 8) + ':agent:*'
      : 'machine:' + shortId(machineId, 10) + ':agent:*';
    $('nsText').textContent = ns;
    $('nsText').title = isLogged
      ? 'acct:' + String(ident.accountId || '') + ':agent:<agentId>'
      : 'machine:' + machineId + ':agent:<agentId>';
    renderScopeButtons();
    renderScopeNotice();
  }

  function renderScopeButtons() {
    const isLogged = loggedIn();
    const acct = $('scopeAcctBtn');
    const machine = $('scopeMachineBtn');
    acct.classList.toggle('is-active', scopeMode === 'acct');
    machine.classList.toggle('is-active', scopeMode === 'machine');
    acct.setAttribute('aria-selected', scopeMode === 'acct' ? 'true' : 'false');
    machine.setAttribute('aria-selected', scopeMode === 'machine' ? 'true' : 'false');
    acct.classList.toggle('is-muted', !isLogged);
    setPill($('statePill'), isLogged ? '已登录 · 账号隔离' : '未登录 · 本机模式', isLogged ? 'pill-acct' : 'pill-muted');
  }

  function renderScopeNotice() {
    const node = $('scopeNotice');
    node.classList.remove('warn');
    if (scopeMode === 'acct') {
      if (!loggedIn()) {
        node.textContent = '请先登录 chat.echenqi.cn，再点右上角「刷新登录态」。未登录时只读写这台电脑的本机记忆，绝不会把本机记忆当作账号记忆读取。';
        node.classList.add('warn');
      } else {
        node.textContent = '仅当前账号可见。同一账号下所有智能体共享同一份记忆；不同账号、不同电脑之间完全隔离。';
      }
    } else {
      node.textContent = loggedIn()
        ? '本机记忆只保存在这台电脑，仅作为当前账号完全没有记忆时的兜底。可在下方「手动提升到账号」写入当前账号；不会自动同步，也不会覆盖账号记忆。'
        : '本机记忆只保存在这台电脑，不受登录状态影响。登录后可手动提升到当前账号（不会自动同步）。';
    }
    $('promoteBtn').disabled = !loggedIn();
    $('refreshAuthBtn').hidden = false;
  }

  function resetStats() {
    stats = null;
    $('statActive').textContent = '0';
    $('statCandidate').textContent = '0';
    $('statSummary').textContent = '0';
    $('statConversations').textContent = '0';
    $('statTurns').textContent = '0';
    $('statStorage').textContent = '—';
  }

  function renderStats() {
    if (!stats || (scopeMode === 'acct' && !loggedIn())) { resetStats(); return; }
    const m = stats.memories || {};
    $('statActive').textContent = String(m.active || 0);
    $('statCandidate').textContent = String(m.candidate || 0);
    $('statSummary').textContent = String(m.summary || 0);
    $('statConversations').textContent = String(stats.conversations || 0);
    $('statTurns').textContent = String(stats.turns || 0);
    const q = stats.quota;
    $('statStorage').textContent = q && q.usage ? fmtBytes(q.usage) : '—';
  }

  function addAgent(id, name) {
    const aid = String(id || '').trim();
    if (!aid || aid === '__global__') return;
    const prev = knownAgents.get(aid) || '';
    const next = String(name || '').trim();
    if (!prev || (next && next !== aid)) knownAgents.set(aid, next || aid);
    else if (!knownAgents.has(aid)) knownAgents.set(aid, aid);
  }

  function collectAgentsFromState() {
    if (!state) return;
    const arr = Array.isArray(state.agentNames) ? state.agentNames : [];
    for (const a of arr) if (a && a.id) addAgent(a.id, a.name);
    const byAgent = stats && Array.isArray(stats.byAgent) ? stats.byAgent : [];
    for (const a of byAgent) if (a && a.agentId) addAgent(a.agentId, a.name);
  }

  function agentLabel(id) {
    const name = knownAgents.get(id) || '';
    if (name && name !== id) return name + '（' + shortId(id, 8) + '）';
    return shortId(id, 12);
  }

  function rebuildAgentOptions() {
    collectAgentsFromState();
    const sel = $('agentFilter');
    const current = sel.value;
    while (sel.firstChild) sel.removeChild(sel.firstChild);
    const all = el('option', '', '全部智能体');
    all.value = '';
    sel.appendChild(all);
    const ids = Array.from(knownAgents.keys()).sort((a, b) => String(knownAgents.get(a) || a).localeCompare(String(knownAgents.get(b) || b), 'zh-CN'));
    for (const id of ids) {
      const opt = el('option', '', agentLabel(id));
      opt.value = id;
      sel.appendChild(opt);
    }
    sel.value = ids.includes(current) ? current : '';
  }

  function badge(text, tone) {
    return el('span', 'tag' + (tone ? ' tag-' + tone : ''), text);
  }

  function statusBadge(status) {
    const map = { active: 'ok', candidate: 'warn', archived: 'muted', superseded: 'muted' };
    return badge(STATUS_LABELS[status] || status || '未知', map[status] || 'muted');
  }

  function turnStatusBadge(status) {
    const map = { summarized: 'ok', completed: 'ok', requesting: 'muted', summarizing: 'warn', 'summary-failed': 'warn', aborted: 'muted', abandoned: 'muted', failed: 'bad', disabled: 'muted' };
    return badge(TURN_STATUS_LABELS[status] || status || '未知', map[status] || 'muted');
  }

  function convSummaryBadge(status) {
    const map = { done: 'ok', pending: 'warn', running: 'warn', failed: 'bad', disabled: 'muted' };
    return badge(CONV_SUMMARY_LABELS[status] || status || '未知', map[status] || 'muted');
  }

  function sourceLabel(src) {
    const s = String(src || '');
    if (!s) return '—';
    if (SOURCE_LABELS[s]) return SOURCE_LABELS[s];
    if (s.startsWith('global-')) return '账号共享（' + sourceLabel(s.slice(7)) + '）';
    return s;
  }

  function metaLine(parts) {
    const line = el('div', 'item-meta');
    for (const p of parts) {
      if (!p) continue;
      line.appendChild(el('span', 'meta-chip', p));
    }
    return line;
  }

  function detailRows(rows) {
    const dl = el('dl', 'detail-grid');
    for (const pair of rows) {
      if (!pair || pair[1] === undefined || pair[1] === null || pair[1] === '') continue;
      dl.appendChild(el('dt', '', pair[0]));
      const dd = el('dd');
      if (pair[2] === 'code') { const code = el('code', '', String(pair[1])); dd.appendChild(code); }
      else dd.textContent = String(pair[1]);
      dl.appendChild(dd);
    }
    return dl;
  }

  function detailsBox(summaryText, rows) {
    const d = el('details', 'item-details');
    d.appendChild(el('summary', '', summaryText));
    d.appendChild(detailRows(rows));
    return d;
  }

  function renderMemoryItem(row) {
    const item = el('article', 'item');
    const head = el('div', 'item-head');
    head.appendChild(el('span', 'item-key', row.key || '未命名字段'));
    head.appendChild(badge(KIND_LABELS[row.kind] || row.kind || '事实', 'kind'));
    head.appendChild(statusBadge(row.status));
    item.appendChild(head);
    item.appendChild(el('p', 'item-value', row.value || ''));
    const agentId = String(row.agentId || '');
    item.appendChild(metaLine([
      '智能体：' + (agentId === '__global__' ? '账号共享画像' : agentLabel(agentId)),
      '置信度：' + fmtPct(row.confidence),
      '确认：' + String(Number(row.confirmCount) || 0) + ' 次',
      '来源：' + sourceLabel(row.source),
      '更新：' + fmtTime(row.updatedAt)
    ]));
    const evidence = Array.isArray(row.evidenceTurns) ? row.evidenceTurns.length : 0;
    item.appendChild(detailsBox('更多字段', [
      ['记忆 ID', row.id || '', 'code'],
      ['命名空间', row.ns || '', 'code'],
      ['实际智能体 ID', agentId, 'code'],
      ['来源智能体', row.sourceAgent || row.sourceAgentName || ''],
      ['重要度', row.importance == null ? '' : fmtPct(row.importance)],
      ['证据轮次', evidence ? String(evidence) + ' 轮' : ''],
      ['最近确认', fmtTime(row.lastConfirmedAt)],
      ['最近使用', fmtTime(row.lastUsedAt)],
      ['标签', Array.isArray(row.tags) && row.tags.length ? row.tags.join('、') : '']
    ]));
    return item;
  }

  function renderConversationItem(row) {
    const item = el('article', 'item');
    const head = el('div', 'item-head');
    head.appendChild(el('span', 'item-key', agentLabel(String(row.agentId || ''))));
    head.appendChild(convSummaryBadge(row.summaryStatus));
    item.appendChild(head);
    item.appendChild(el('p', 'item-sub', '对话 ' + shortId(row.conversationId, 12)));
    item.appendChild(metaLine([
      '轮次：' + String(Number(row.turnCount) || 0),
      '消息：' + String(Number(row.messageCount) || 0),
      '最近提问：' + fmtTime(row.lastUserAt),
      '更新：' + fmtTime(row.updatedAt),
      '总结来源：' + sourceLabel(row.summarySource)
    ]));
    const actions = el('div', 'item-actions');
    const btn = el('button', 'btn btn-ghost btn-small', '查看轮次');
    btn.type = 'button';
    btn.addEventListener('click', () => {
      conversationId = String(row.conversationId || '');
      setView('turns');
    });
    actions.appendChild(btn);
    item.appendChild(actions);
    item.appendChild(detailsBox('更多字段', [
      ['对话 ID', row.id || '', 'code'],
      ['原始会话 ID', row.conversationId || '', 'code'],
      ['智能体 ID', row.agentId || '', 'code'],
      ['命名空间', row.ns || '', 'code'],
      ['创建时间', fmtTime(row.createdAt)],
      ['最近总结', fmtTime(row.lastSummaryAt)]
    ]));
    return item;
  }

  function renderTurnItem(row) {
    const item = el('article', 'item');
    const head = el('div', 'item-head');
    head.appendChild(el('span', 'item-key', agentLabel(String(row.agentId || ''))));
    head.appendChild(turnStatusBadge(row.status));
    item.appendChild(head);
    item.appendChild(metaLine([
      '开始：' + fmtTime(row.startedAt),
      '完成：' + fmtTime(row.completedAt),
      '对话：' + shortId(row.conversationId, 10)
    ]));
    const u = el('div', 'turn-block');
    u.appendChild(el('div', 'turn-label', '用户'));
    u.appendChild(el('p', 'turn-text', clipText(row.userText, 600)));
    item.appendChild(u);
    if (row.assistantText) {
      const a = el('div', 'turn-block');
      a.appendChild(el('div', 'turn-label', 'AI'));
      a.appendChild(el('p', 'turn-text', clipText(row.assistantText, 600)));
      item.appendChild(a);
    }
    if (row.summary) {
      const s = el('div', 'turn-block turn-summary-block');
      s.appendChild(el('div', 'turn-label', '本轮摘要'));
      s.appendChild(el('p', 'turn-summary', row.summary));
      item.appendChild(s);
    }
    if (row.summaryError) item.appendChild(el('p', 'turn-error', '总结错误：' + row.summaryError));
    item.appendChild(detailsBox('更多字段', [
      ['轮次 ID', row.id || '', 'code'],
      ['对话 ID', row.conversationId || '', 'code'],
      ['命名空间', row.ns || '', 'code'],
      ['是否已总结', row.summarized ? '是' : '否'],
      ['总结时间', fmtTime(row.summaryAt)],
      ['提取记忆数', row.memoryCount == null ? '' : String(row.memoryCount)],
      ['总结来源', sourceLabel(row.summarySource)]
    ]));
    return item;
  }

  function renderEmpty(text, tone) {
    const box = el('div', 'empty' + (tone ? ' ' + tone : ''));
    box.appendChild(el('p', '', text));
    return box;
  }

  function renderListHead(total, shown) {
    const head = $('listHead');
    if (total === null) { head.textContent = '—'; return; }
    head.textContent = shown < total ? ('共 ' + total + ' 条，显示前 ' + shown + ' 条') : ('共 ' + total + ' 条');
  }

  function renderRows(rows) {
    const list = $('list');
    while (list.firstChild) list.removeChild(list.firstChild);
    const frag = document.createDocumentFragment();
    for (const row of rows) {
      if (view === 'memories') frag.appendChild(renderMemoryItem(row));
      else if (view === 'conversations') frag.appendChild(renderConversationItem(row));
      else frag.appendChild(renderTurnItem(row));
    }
    list.appendChild(frag);
  }

  async function refreshStats() {
    if (scopeMode === 'acct' && !loggedIn()) { resetStats(); return; }
    const r = await uiMsg('stats', scopePayload());
    if (!r || !r.ok) {
      resetStats();
      if (r && r.reason && r.reason !== 'extension-error') setStatus('统计读取失败：' + r.reason, true);
      return;
    }
    stats = r;
    renderStats();
    rebuildAgentOptions();
  }

  async function refreshList() {
    const token = ++listToken;
    if (scopeMode === 'acct' && !loggedIn()) {
      renderListHead(0, 0);
      const list = $('list');
      while (list.firstChild) list.removeChild(list.firstChild);
      list.appendChild(renderEmpty('未登录：账号记忆不可读取。请先登录 chat.echenqi.cn，再点「刷新登录态」。', 'warn'));
      return;
    }
    const payload = Object.assign({}, scopePayload());
    const agentId = $('agentFilter').value;
    if (agentId) payload.agentId = agentId;
    let type = 'list-memories';
    if (view === 'memories') {
      payload.status = $('statusFilter').value || 'visible';
      const kind = $('kindFilter').value;
      if (kind) payload.kind = kind;
      const q = $('searchInput').value.trim();
      if (q) payload.q = q;
    } else if (view === 'conversations') {
      type = 'list-conversations';
    } else {
      type = 'list-turns';
      if (conversationId) payload.conversationId = conversationId;
    }
    const r = await uiMsg(type, payload);
    if (token !== listToken) return;
    if (!r || !r.ok) {
      renderListHead(null, 0);
      const list = $('list');
      while (list.firstChild) list.removeChild(list.firstChild);
      list.appendChild(renderEmpty('读取失败：' + String((r && r.reason) || '未知错误'), 'warn'));
      return;
    }
    if (scopeMode === 'acct' && view === 'memories' && r.identity && r.identity.scope !== 'acct') {
      renderListHead(0, 0);
      const list = $('list');
      while (list.firstChild) list.removeChild(list.firstChild);
      list.appendChild(renderEmpty('登录态已失效：本次请求没有拿到账号记忆。请重新登录后刷新登录态。', 'warn'));
      return;
    }
    const rows = Array.isArray(r.rows) ? r.rows : [];
    for (const row of rows) if (row && row.agentId) addAgent(row.agentId, row.agentName);
    rebuildAgentOptions();
    renderListHead(Number(r.total) || rows.length, rows.length);
    renderRows(rows);
    if (!rows.length) {
      const list = $('list');
      while (list.firstChild) list.removeChild(list.firstChild);
      let msg = '暂无记忆。与智能体聊几轮后，扩展会自动总结并写入这里。';
      if (view === 'conversations') msg = '暂无对话记录。';
      if (view === 'turns') msg = '暂无轮次记录。';
      list.appendChild(renderEmpty(msg));
    }
    if (view === 'turns') renderCrumb();
  }

  function renderCrumb() {
    const box = $('conversationCrumb');
    if (view === 'turns' && conversationId) {
      box.hidden = false;
      $('crumbText').textContent = shortId(conversationId, 14);
      $('crumbText').title = conversationId;
    } else {
      box.hidden = true;
      $('crumbText').textContent = '—';
    }
  }

  function setView(next) {
    view = next === 'conversations' || next === 'turns' ? next : 'memories';
    if (view !== 'turns') conversationId = '';
    const tabs = [
      ['tabMemories', 'memories'],
      ['tabConversations', 'conversations'],
      ['tabTurns', 'turns']
    ];
    for (const [id, key] of tabs) {
      const b = $(id);
      b.classList.toggle('is-active', view === key);
      b.setAttribute('aria-selected', view === key ? 'true' : 'false');
    }
    $('statusField').hidden = view !== 'memories';
    $('kindField').hidden = view !== 'memories';
    $('searchField').hidden = view !== 'memories';
    renderCrumb();
    void refreshList();
  }

  function setScope(next) {
    const mode = next === 'machine' ? 'machine' : 'acct';
    scopeChosen = true;
    if (mode === scopeMode) return;
    scopeMode = mode;
    conversationId = '';
    resetStats();
    renderIdentity();
    setStatus('');
    if (scopeMode === 'acct' && !loggedIn()) {
      renderListHead(0, 0);
      const list = $('list');
      while (list.firstChild) list.removeChild(list.firstChild);
      list.appendChild(renderEmpty('请先登录 chat.echenqi.cn，再点「刷新登录态」。未登录时不会读取或复用本机记忆作为账号记忆。', 'warn'));
      return;
    }
    void refreshStats();
    void refreshList();
  }

  async function reloadAll(silent) {
    if (!silent) setStatus('读取中…');
    setPill($('statePill'), '读取中', '');
    const r = await uiMsg('get-state');
    if (!r || !r.ok) {
      setPill($('statePill'), '异常', 'pill-warn');
      setStatus('读取失败：' + String((r && r.reason) || '未知错误'), true);
      return;
    }
    state = r;
    if (!scopeChosen) {
      scopeMode = loggedIn() ? 'acct' : 'machine';
    }
    knownAgents = new Map();
    collectAgentsFromState();
    rebuildAgentOptions();
    renderIdentity();
    resetStats();
    if (scopeMode === 'acct' && !loggedIn()) {
      renderListHead(0, 0);
      const list = $('list');
      while (list.firstChild) list.removeChild(list.firstChild);
      list.appendChild(renderEmpty('请先登录 chat.echenqi.cn，再点「刷新登录态」。未登录时不会读取或复用本机记忆作为账号记忆。', 'warn'));
      if (!silent) setStatus('');
      return;
    }
    await Promise.all([refreshStats(), refreshList()]);
    if (!silent) setStatus('');
  }

  function bindEvents() {
    $('scopeAcctBtn').addEventListener('click', () => setScope('acct'));
    $('scopeMachineBtn').addEventListener('click', () => setScope('machine'));
    $('tabMemories').addEventListener('click', () => setView('memories'));
    $('tabConversations').addEventListener('click', () => setView('conversations'));
    $('tabTurns').addEventListener('click', () => { conversationId = ''; setView('turns'); });
    $('clearCrumbBtn').addEventListener('click', () => { conversationId = ''; renderCrumb(); void refreshList(); });

    $('agentFilter').addEventListener('change', () => void refreshList());
    $('statusFilter').addEventListener('change', () => void refreshList());
    $('kindFilter').addEventListener('change', () => void refreshList());
    $('searchInput').addEventListener('input', () => {
      if (searchTimer) clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { searchTimer = null; void refreshList(); }, 260);
    });
    $('reloadBtn').addEventListener('click', () => void reloadAll(false));

    $('refreshAuthBtn').addEventListener('click', async () => {
      setStatus('正在刷新登录态…');
      const r = await uiMsg('refresh-auth');
      if (!r || !r.ok) {
        setStatus('刷新失败：' + String((r && r.reason) || '请在已登录的 chat.echenqi.cn 页面重试'), true);
        return;
      }
      await reloadAll(true);
      if (r.loggedOut) setStatus('未检测到登录账号，当前只能使用本机记忆。', true);
      else setStatus('登录态已刷新：' + (loggedIn() ? '账号记忆可用' : '仍为未登录状态'), !loggedIn());
    });

    $('openSiteBtn').addEventListener('click', () => {
      try { chrome.tabs.create({ url: 'https://chat.echenqi.cn/' }); } catch (_) {}
    });

    $('exportBtn').addEventListener('click', async () => {
      if (!scopeUsable()) return;
      setStatus('正在导出…');
      const r = await uiMsg('export', scopePayload());
      if (!r || !r.ok || !r.data) {
        setStatus('导出失败：' + String((r && r.reason) || '未知错误'), true);
        return;
      }
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const scopeName = scopeMode === 'acct' ? ('account-' + String((state.identity && state.identity.accountId) || '').slice(-6)) : ('machine-' + String((state && state.machineId) || '').slice(-6));
      const blob = new Blob([JSON.stringify(r.data, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ecq-memory-' + scopeName + '-' + stamp + '.json';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => { try { URL.revokeObjectURL(url); } catch (_) {} }, 4000);
      const c = r.data.counts || {};
      setStatus('导出完成：记忆 ' + String(c.memories || 0) + ' 条，对话 ' + String(c.conversations || 0) + ' 个，轮次 ' + String(c.turns || 0) + ' 条。');
    });

    $('importBtn').addEventListener('click', () => {
      if (!scopeUsable()) return;
      $('importFile').click();
    });
    $('importFile').addEventListener('change', async () => {
      const input = $('importFile');
      const file = input.files && input.files[0];
      input.value = '';
      if (!file) return;
      if (!scopeUsable()) return;
      let data = null;
      try {
        const text = await file.text();
        data = JSON.parse(text);
      } catch (e) {
        setStatus('导入失败：文件不是有效 JSON。', true);
        return;
      }
      if (!data || typeof data !== 'object') { setStatus('导入失败：备份内容为空。', true); return; }
      if (!window.confirm('将备份导入到「' + scopeLabel() + '」？已存在的相同记忆会合并，不会删除现有数据。')) return;
      setStatus('正在导入…');
      const r = await uiMsg('import', Object.assign(scopePayload(), { data }));
      if (!r || !r.ok) {
        const reason = String((r && r.reason) || '未知错误');
        const map = { 'scope-mismatch': '备份范围与当前范围不一致', 'account-mismatch': '备份属于其他账号', 'machine-mismatch': '备份属于其他电脑', 'bad-data': '备份格式不正确' };
        setStatus('导入失败：' + (map[reason] || reason), true);
        return;
      }
      setStatus('导入完成：记忆 ' + String(r.imported || 0) + ' 条（跳过 ' + String(r.skipped || 0) + '），对话 ' + String(r.importedConversations || 0) + ' 个，轮次 ' + String(r.importedTurns || 0) + ' 条。');
      await reloadAll(true);
    });

    $('promoteBtn').addEventListener('click', async () => {
      if (!loggedIn()) { setStatus('请先登录后再提升本机记忆。', true); return; }
      if (scopeMode !== 'machine') { setStatus('请先切到「本机记忆」范围，再执行提升。', true); return; }
      const agentId = $('agentFilter').value;
      const target = agentId ? agentLabel(agentId) : '全部智能体';
      if (!window.confirm('仅把本机记忆中「' + target + '」的有效条目手动写入当前账号？不会自动同步，也不会覆盖其他账号；账号已有同键记忆会按合并规则更新。')) return;
      setStatus('正在提升…');
      const payload = agentId ? { agentId } : {};
      const r = await uiMsg('promote-machine', payload);
      if (!r || !r.ok) {
        setStatus('提升失败：' + String((r && r.reason === 'need-login' ? '需要先登录' : (r && r.reason) || '未知错误')), true);
        return;
      }
      setStatus('提升完成：写入 ' + String(r.promoted || 0) + ' 条，涉及 ' + String(r.agents || 0) + ' 个智能体。');
      await reloadAll(true);
    });

    $('clearBtn').addEventListener('click', async () => {
      if (!scopeUsable()) return;
      const confirmText = $('clearConfirm').value;
      if (confirmText !== 'CLEAR') { setStatus('清空需要在输入框里完整输入 CLEAR。', true); return; }
      const onlyAgent = $('clearOnlyAgent').checked;
      const agentId = onlyAgent ? $('agentFilter').value : '';
      if (onlyAgent && !agentId) { setStatus('勾选「仅清空当前筛选的智能体」时，请先在筛选里选择具体智能体。', true); return; }
      const label = scopeLabel() + (agentId ? ' · ' + agentLabel(agentId) : ' · 全部智能体');
      if (!window.confirm('确定清空「' + label + '」？此操作不可撤销。')) return;
      setStatus('正在清空…');
      const payload = Object.assign({ confirm: 'CLEAR' }, scopePayload());
      if (agentId) payload.agentId = agentId;
      const r = await uiMsg('clear', payload);
      if (!r || !r.ok) {
        setStatus('清空失败：' + String((r && r.reason === 'need-confirm' ? '确认口令不正确' : (r && r.reason) || '未知错误')), true);
        return;
      }
      $('clearConfirm').value = '';
      setStatus('已清空 ' + String(r.cleared || 0) + ' 条记录。');
      await reloadAll(true);
    });

    $('diagBtn').addEventListener('click', async () => {
      const out = $('diagOut');
      out.textContent = '读取诊断中…';
      const r = await uiMsg('debug');
      if (!r || !r.ok) {
        out.textContent = '诊断失败：' + String((r && r.reason) || 'unknown');
        return;
      }
      const page = Array.isArray(r.pageDebug) ? r.pageDebug : [];
      const bg = Array.isArray(r.debug) ? r.debug : [];
      const counts = {};
      for (const item of page.concat(bg)) counts[item.kind] = (counts[item.kind] || 0) + 1;
      const lines = [];
      lines.push('identity=' + JSON.stringify(r.identity || {}));
      lines.push('machineId=' + String(r.machineId || ''));
      lines.push('pageDebug=' + page.length + '  backgroundDebug=' + bg.length);
      lines.push('事件计数=' + JSON.stringify(counts));
      const live = r.live || null;
      if (live) {
        lines.push('=== LIVE ===');
        lines.push('tabs=' + JSON.stringify(live.tabs || []));
        if (live.error) lines.push('liveError=' + live.error);
        const frames = Array.isArray(live.live) ? live.live : [];
        lines.push('frames=' + frames.length);
        frames.forEach((f, i) => {
          const fd = Array.isArray(f.debug) ? f.debug : [];
          const fn = Array.isArray(f.net) ? f.net : [];
          lines.push('[frame ' + i + '] frameId=' + String(f.frameId == null ? '' : f.frameId) + ' isTop=' + !!f.isTop + ' pageV2=' + !!f.pageV2 + ' pageAttr=' + String(f.pageAttr || '-') + ' contentAttr=' + String(f.contentAttr || '-'));
          lines.push('  href=' + String(f.href || ''));
          lines.push('  boot=' + JSON.stringify(f.boot || null) + ' debug=' + fd.length + ' net=' + fn.length);
          fd.slice(-40).forEach((x) => {
            lines.push('  D ' + new Date(x.ts || Date.now()).toLocaleTimeString() + ' ' + String(x.kind || '') + ' ' + JSON.stringify(x.data || {}));
          });
          fn.slice(-20).forEach((x) => {
            lines.push('  N ' + new Date(x.ts || Date.now()).toLocaleTimeString() + ' ' + String(x.phase || '') + ' ' + String(x.method || '') + ' ' + String(x.path || '') + ' status=' + String(x.status == null ? '' : x.status));
          });
        });
      }
      lines.push('=== PAGE ===');
      page.slice(-80).forEach((x) => {
        lines.push(new Date(x.ts || Date.now()).toLocaleTimeString() + ' ' + x.kind + ' ' + JSON.stringify(x.data || {}));
      });
      lines.push('=== BACKGROUND ===');
      bg.slice(-100).forEach((x) => {
        lines.push(new Date(x.ts || Date.now()).toLocaleTimeString() + ' ' + x.kind + ' ' + JSON.stringify(x.data || {}));
      });
      out.textContent = lines.join('\n');
    });
  }

  window.addEventListener('unhandledrejection', (e) => {
    try { setStatus('发生异常：' + String((e && e.reason && e.reason.message) || e.reason || 'unknown'), true); } catch (_) {}
  });

  bindEvents();
  void reloadAll(false);
})();
