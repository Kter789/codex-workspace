# ECQ 本地记忆扩展 v2.0.6

为 `https://chat.echenqi.cn` 提供本地长期记忆。同一账号下所有智能体共享记忆；不同账号、不同电脑严格隔离。记忆保存在本机浏览器 IndexedDB，不上传服务器，不修改平台服务端。

## 下载

- 推荐（国内可用）：<https://ghproxy.net/https://raw.githubusercontent.com/Kter789/codex-workspace/main/ecq-memory-extension/ecq-memory-extension-v2.0.6.zip>
- 固定版本 v2.0.6：<https://ghproxy.net/https://raw.githubusercontent.com/Kter789/codex-workspace/main/ecq-memory-extension/ecq-memory-extension-v2.0.6.zip>

> jsDelivr 在部分网络下无法访问，不再作为主下载地址。

## 安装

入口：AI记忆教练标题上方的「下载 / 安装扩展」按钮。

1. 下载压缩包后解压到一个固定目录，例如 `D:\ECQ\ecq-memory-extension`。压缩包里就是 `ecq-memory-extension` 文件夹，`manifest.json` 在文件夹第一层。
2. Edge 打开 `edge://extensions`，开启“开发人员模式”。
3. 点“加载解压缩的扩展”，选择直接包含 `manifest.json` 的文件夹。
4. 回到 `https://chat.echenqi.cn` 刷新。
5. 打开“AI记忆教练”，点标题上方的“打开记忆管理”；首次可点扩展图标里的“刷新登录态”。

浏览器不允许网页一键静默安装扩展，必须手动加载。每台电脑装一次，记忆不跨电脑自动同步；换电脑请用“导出/导入 JSON”迁移。

## 记忆规则

- 账号记忆：按当前登录账号隔离。
- 全智能体共享：同一账号下，一个智能体形成的记忆会自动同步到共享记忆，其他智能体直接可用。
- 本机记忆：未登录时或账号无记忆时，使用这台电脑的兜底空间。
- 跨账号/跨电脑严格隔离，不会串记忆。
- 本机索引数据库：`ecq_memory`。

详细步骤见扩展目录内的 `使用说明.txt`。



