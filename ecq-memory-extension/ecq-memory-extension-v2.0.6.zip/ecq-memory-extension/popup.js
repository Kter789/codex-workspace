(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  let state = null;
  let stats = null;

  function uiMsg(type, payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, payload: payload || {} }, (resp) => {
          let err = null;
          try { err = chrome.runtime.lastError; } catch (_) {}
          if (err) resolve({ ok: false, reason: String(err.message || 'extension-error') });
          else resolve(resp || { ok: false, reason: 'empty-response' });
        });
      } catch (e) {
        resolve({ ok: false, reason: String((e && e.message) || 'send-failed') });
      }
    });
  }

  function shortId(v) {
    const s = String(v || '');
    if (!s) return '—';
    return s.length <= 12 ? s : s.slice(0, 6) + '…' + s.slice(-4);
  }

  function setPill(el, text, tone) {
    el.textContent = text;
    el.className = 'pill' + (tone ? ' ' + tone : '');
  }

  function setStatus(text, isError) {
    const el = $('statusText');
    el.textContent = text || '';
    el.classList.toggle('error', !!isError);
  }

  function renderIdentity() {
    const ident = (state && state.identity) || {};
    const logged = !!ident.loggedIn && !!ident.accountId;
    const name = ident.name || ident.username || (logged ? '已登录账号' : '本机使用中');
    $('identityName').textContent = name;
    setPill($('scopePill'), logged ? '账号记忆' : '本机记忆', logged ? 'pill-acct' : 'pill-muted');
    const meta = [];
    if (logged) {
      if (ident.username && ident.username !== name) meta.push('账号 ' + ident.username);
      meta.push('ID ' + shortId(ident.accountId));
    } else {
      meta.push('未登录 · 只会读写本机记忆');
    }
    $('identityMeta').textContent = meta.join(' · ');
    $('machineText').textContent = shortId(state && state.machineId);
    const base = logged ? 'acct:' + String(ident.accountId) + ':agent:' : 'machine:' + String((state && state.machineId) || '') + ':agent:';
    $('nsText').textContent = base + '*';
  }

  function fmtBytes(n) {
    const v = Number(n) || 0;
    if (!v) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0; let x = v;
    while (x >= 1024 && i < units.length - 1) { x /= 1024; i++; }
    return (x >= 10 ? x.toFixed(0) : x.toFixed(1)) + ' ' + units[i];
  }

  function renderStats() {
    const m = (stats && stats.memories) || {};
    $('statActive').textContent = String(m.active || 0);
    $('statCandidate').textContent = String(m.candidate || 0);
    $('statTurns').textContent = String((stats && stats.turns) || 0);
    $('statAgents').textContent = String(((stats && stats.byAgent) || []).length);
    const q = stats && stats.quota;
    $('storageText').textContent = q ? fmtBytes(q.usage) + (q.quota ? ' / ' + fmtBytes(q.quota) : '') : '—';
  }

  function renderSettings() {
    const st = (state && state.settings) || {};
    for (const key of ['observeOnly', 'autoSummarize', 'useLocalAI', 'machineFallback', 'shareGlobal']) {
      const el = $(key);
      if (el) el.checked = !!st[key];
    }
    $('fallbackRisk').hidden = !st.machineFallback;
  }

  async function loadAll() {
    setStatus('读取中…');
    const r = await uiMsg('get-state');
    if (!r.ok) { setStatus('读取失败：' + (r.reason || 'unknown'), true); setPill($('statePill'), '异常', 'pill-warn'); return; }
    state = r;
    renderIdentity();
    renderSettings();
    const s = await uiMsg('stats');
    stats = s.ok ? s : null;
    renderStats();
    setPill($('statePill'), (state.identity && state.identity.loggedIn) ? '已连接' : '本机', (state.identity && state.identity.loggedIn) ? 'pill-acct' : 'pill-muted');
    setStatus('');
  }

  async function saveSetting(key, value) {
    const payload = {}; payload[key] = value;
    const r = await uiMsg('set-settings', payload);
    if (!r.ok) { setStatus('保存失败：' + (r.reason || 'unknown'), true); return; }
    state.settings = r.settings;
    renderSettings();
    setStatus('已保存');
    if (key === 'observeOnly' || key === 'machineFallback' || key === 'shareGlobal') {
      const s = await uiMsg('stats');
      if (s.ok) { stats = s; renderStats(); }
    }
  }

  for (const key of ['observeOnly', 'autoSummarize', 'useLocalAI', 'machineFallback', 'shareGlobal']) {
    $(key).addEventListener('change', (e) => { void saveSetting(key, !!e.target.checked); });
  }

  $('refreshBtn').addEventListener('click', async () => {
    setStatus('正在刷新登录态…');
    const r = await uiMsg('refresh-auth');
    if (!r.ok) { setStatus('刷新失败：' + (r.reason || '请在已登录的 chat.echenqi.cn 页面重试'), true); return; }
    await loadAll();
    setStatus('登录态已刷新');
  });

  $('openBtn').addEventListener('click', () => {
    try { chrome.runtime.openOptionsPage(); } catch (_) { chrome.tabs.create({ url: 'memory.html' }); }
    window.close();
  });

  void loadAll();
})();
