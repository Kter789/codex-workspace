(() => {
  const url = 'https://ghproxy.net/https://raw.githubusercontent.com/Kter789/codex-workspace/main/ecq-memory-extension/ecq-memory-extension-v2.0.7.zip';
  const btn = document.getElementById('copy-link');
  const toast = document.getElementById('toast');
  let timer = null;
  if (!btn) return;
  btn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(url);
      if (toast) {
        toast.classList.add('show');
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => toast.classList.remove('show'), 1800);
      }
    } catch (_) {
      window.prompt('复制下面的下载地址：', url);
    }
  });
})();
