/* ECQ 本地记忆 v2 · 页面桥接（ISOLATED world）
 * 只做三件事：把页面请求转给后台、把后台回复转回页面、转发登录/设置广播。
 * 不读取页面 DOM，不注入界面，不广播任何 token。
 */
(() => {
  'use strict';
  if (window.__ECQ_MEM_CONTENT_V2__) return;
  window.__ECQ_MEM_CONTENT_V2__ = true;
  try { document.documentElement.dataset.ecqContent = '1'; } catch (_) {}

  const SOURCE_PAGE = 'ecq-mem-page';
  const SOURCE_BG = 'ecq-mem-bg';
  const ALLOWED = new Set([
    'get-context', 'chat-request', 'chat-complete', 'auth', 'logout',
    'cancel-turn', 'request-auth', 'page-debug', 'ping-page', 'get-state'
  ]);
  const BROADCAST = new Set(['request-auth', 'settings-changed', 'session-updated']);

  function sendToBackground(type, payload) {
    return new Promise((resolve) => {
      let settled = false;
      const done = (value) => {
        if (settled) return;
        settled = true;
        resolve(value && typeof value === 'object' ? value : { ok: false, reason: 'empty-response' });
      };
      try {
        chrome.runtime.sendMessage({ source: SOURCE_PAGE, type, payload: payload || {} }, (resp) => {
          let lastError = null;
          try { lastError = chrome.runtime.lastError; } catch (_) {}
          if (lastError) {
            done({ ok: false, reason: String(lastError.message || 'extension-context-error') });
            return;
          }
          done(resp);
        });
      } catch (e) {
        done({ ok: false, reason: String((e && e.message) || 'send-failed') });
      }
    });
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window) return;
    const msg = ev.data;
    if (!msg || msg.source !== SOURCE_PAGE) return;
    const type = String(msg.type || '');
    if (!ALLOWED.has(type)) return;
    const payload = (msg.payload && typeof msg.payload === 'object') ? msg.payload : {};
    const reqId = msg.reqId ? String(msg.reqId).slice(0, 80) : '';
    void sendToBackground(type, payload).then((result) => {
      if (!reqId) return;
      try {
        window.postMessage({ source: SOURCE_BG, type: 'reply', reqId, of: type, payload: result }, '*');
      } catch (_) {}
    });
  });

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.source !== SOURCE_BG) return;
      const type = String(msg.type || '');
      if (!BROADCAST.has(type)) return;
      try {
        window.postMessage({
          source: SOURCE_BG,
          type,
          payload: msg.payload == null ? null : msg.payload,
          ts: Number(msg.ts) || Date.now()
        }, '*');
      } catch (_) {}
    });
  } catch (_) {}
})();

/* 线上页入口：只在「AI记忆教练」对话页注入；不修改平台服务端。 */
(() => {
  'use strict';
  if (window.top !== window) return;
  if (window.__ECQ_MEM_ENTRY_UI__) return;
  window.__ECQ_MEM_ENTRY_UI__ = true;

  const TARGET = 'AI记忆教练';
  const SUB_WORDS = ['聊天自动记', '管理本地记忆', '越用越懂你'];
  const state = {
    identity: null,
    identityRequested: false,
    node: null,
    small: null,
    wrap: null,
    installNode: null,
    emptyRoot: null,
    missCount: 0,
    overlay: null,
    savedOverlay: null,
    list: null,
    listInline: '',
    listBase: null,
    checking: false
  };

  const norm = (v) => String(v || '').replace(/\s+/g, '');
  const isChatPage = () => /^\/c\/[^/?#]+/.test(location.pathname);
  const visibleRect = (el) => {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return null;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) return null;
    return r;
  };
  const hasTarget = (el) => !!el && norm(el.textContent).includes(TARGET);

  function findMain() {
    const all = Array.from(document.querySelectorAll('main'));
    for (const el of all) if (visibleRect(el)) return el;
    return null;
  }

  function findSubtitle(main) {
    let best = null;
    for (const el of main.querySelectorAll('span,p,div')) {
      if (el.children.length) continue;
      const text = norm(el.textContent);
      if (!text || !SUB_WORDS.some((w) => text.includes(w))) continue;
      const r = visibleRect(el);
      if (!r) continue;
      if (!best || r.top < best.top) best = { el, top: r.top };
    }
    return best ? best.el : null;
  }

  function findBigTitle(main) {
    let best = null;
    let bestSize = 0;
    for (const el of main.querySelectorAll('span,p')) {
      if (norm(el.textContent) !== TARGET) continue;
      const r = visibleRect(el);
      if (!r || r.top < 100) continue;
      const size = parseFloat(getComputedStyle(el).fontSize) || 0;
      if (size < 18) continue;
      if (size > bestSize) { best = el; bestSize = size; }
    }
    return best;
  }

  function findEmptyRoot(main) {
    const mr = main.getBoundingClientRect();
    const sub = findSubtitle(main);
    let first = sub;
    let best = null;
    for (let i = 0; first && i < 7 && first !== main; i++, first = first.parentElement) {
      const r = visibleRect(first);
      if (!r) continue;
      if (r.height > 380 || r.width > mr.width * 0.96) continue;
      if (hasTarget(first)) best = first;
    }
    if (best) return best;

    let title = findBigTitle(main);
    if (!title) return null;
    best = title;
    for (let i = 0; title && i < 7 && title !== main; i++, title = title.parentElement) {
      const r = visibleRect(title);
      if (!r) continue;
      if (r.height > 380 || r.width > mr.width * 0.96) continue;
      if (hasTarget(title)) best = title;
    }
    return best;
  }

  function findHeaderTitle(main) {
    let best = null;
    for (const el of main.querySelectorAll('span,p')) {
      if (norm(el.textContent) !== TARGET) continue;
      const r = visibleRect(el);
      if (!r || r.top < 45 || r.top > 260 || r.width > 320) continue;
      const size = parseFloat(getComputedStyle(el).fontSize) || 0;
      if (size > 19) continue;
      if (!best || r.top < best.top) best = { el, top: r.top };
    }
    return best ? best.el : null;
  }

  function overlayFromTitle(title) {
    let p = title;
    for (let i = 0; i < 9 && p; i++, p = p.parentElement) {
      const cls = String(p.className || '');
      if (p.tagName === 'DIV' && cls.includes('absolute') && cls.includes('top-0')) return p;
    }
    return null;
  }

  function findMessageList(main) {
    let fallback = null;
    for (const el of main.querySelectorAll('div')) {
      const cls = String(el.className || '');
      if (!cls.includes('flex-col')) continue;
      if (!visibleRect(el)) continue;
      if (cls.includes('pb-32')) return el;
      if (!fallback && (cls.includes('overflow-y-auto') || cls.includes('overflow-auto'))) fallback = el;
    }
    return fallback;
  }

  function accountLabel() {
    const u = state.identity || {};
    const name = String(u.name || u.username || '').trim();
    if (String(u.role || '').toUpperCase() === 'ADMIN') {
      const admin = name ? (name.startsWith('管理员') ? name : '管理员 ' + name) : '管理员';
      return admin + ' · 可切换账号';
    }
    return name ? ('当前账号 ' + name + ' · 仅自己可见') : '按当前账号隔离 · 仅自己可见';
  }

  function updateLabel() {
    if (!state.small) return;
    state.small.textContent = accountLabel();
  }

  function loadIdentity() {
    if (state.identity || state.identityRequested) return;
    state.identityRequested = true;
    try {
      chrome.runtime.sendMessage({ type: 'get-state' }, (resp) => {
        let err = null;
        try { err = chrome.runtime.lastError; } catch (_) {}
        if (err || !resp || !resp.ok) { state.identityRequested = false; return; }
        state.identity = resp.identity || null;
        updateLabel();
      });
    } catch (_) {
      state.identityRequested = false;
    }
  }

  function openMemory() {
    try {
      chrome.runtime.sendMessage({ type: 'open-memory' }, (resp) => {
        let err = null;
        try { err = chrome.runtime.lastError; } catch (_) {}
        if ((err || !resp || !resp.ok) && state.small) state.small.textContent = '打开失败，请点扩展图标进入记忆管理';
      });
    } catch (_) {
      if (state.small) state.small.textContent = '打开失败，请点扩展图标进入记忆管理';
    }
  }

  function openInstall() {
    try {
      chrome.runtime.sendMessage({ type: 'open-install' }, (resp) => {
        let err = null;
        try { err = chrome.runtime.lastError; } catch (_) {}
        if (err || !resp || !resp.ok) {
          try {
            window.open('https://ghfast.top/https://raw.githubusercontent.com/Kter789/codex-workspace/main/ecq-memory-extension/ecq-memory-extension-v2.0.8.zip', '_blank', 'noopener');
          } catch (_) {}
        }
      });
    } catch (_) {
      try {
      window.open('https://ghfast.top/https://raw.githubusercontent.com/Kter789/codex-workspace/main/ecq-memory-extension/ecq-memory-extension-v2.0.8.zip', '_blank', 'noopener');
      } catch (_) {}
    }
  }

  function buildNode() {
    if (state.node) return state.node;
    const b = document.createElement('button');
    b.type = 'button';
    b.id = 'ecq-mem-entry';
    b.title = '只显示当前辰岐账号的记忆；管理员可切换账号';
    b.setAttribute('aria-label', '打开记忆管理');
    b.innerHTML = '<span class="ecq-mem-entry-icon" aria-hidden="true">'
      + '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'
      + '<path d="M12 3.2c-3.9 0-6.8 2.6-6.8 6.2 0 1.5.5 2.8 1.5 3.8-.2.9-.6 1.8-1.2 2.6 1.3.1 2.4-.2 3.3-.8 1 .4 2.1.6 3.2.6 3.9 0 6.8-2.6 6.8-6.2S15.9 3.2 12 3.2Z"></path>'
      + '<path d="M9.2 20.8c.9-.2 1.7-.7 2.3-1.4.6.7 1.4 1.2 2.3 1.4"></path>'
      + '<path d="M9.4 9.6h.01M14.6 9.6h.01"></path>'
      + '</svg></span>'
      + '<span class="ecq-mem-entry-text"><strong>打开记忆管理</strong><small></small></span>'
      + '<span class="ecq-mem-entry-arrow" aria-hidden="true">›</span>';
    state.small = b.querySelector('small');
    b.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openMemory();
    }, true);
    state.node = b;
    updateLabel();
    return b;
  }

  function buildInstallNode() {
    if (state.installNode) return state.installNode;
    const b = document.createElement('button');
    b.type = 'button';
    b.id = 'ecq-mem-install';
    b.title = '下载安装包，装到其他电脑或分享给同事、学员';
    b.setAttribute('aria-label', '下载或安装本地记忆扩展');
    b.innerHTML = '<span class="ecq-mem-install-icon" aria-hidden="true">'
      + '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'
      + '<path d="M12 3v11"></path>'
      + '<path d="m7.5 9.5 4.5 4.5 4.5-4.5"></path>'
      + '<path d="M4.5 20.5h15"></path>'
      + '</svg></span>'
      + '<span class="ecq-mem-install-text"><strong>下载 / 安装扩展</strong><small>装到其他电脑或分享给同事</small></span>'
      + '<span class="ecq-mem-install-arrow" aria-hidden="true">↗</span>';
    b.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openInstall();
    }, true);
    state.installNode = b;
    return b;
  }

  function buildWrap() {
    if (state.wrap) return state.wrap;
    const wrap = document.createElement('div');
    wrap.id = 'ecq-mem-entry-wrap';
    wrap.appendChild(buildInstallNode());
    wrap.appendChild(buildNode());
    state.wrap = wrap;
    return wrap;
  }

  function saveOverlay(overlay) {
    if (state.overlay === overlay && state.savedOverlay) return;
    restoreOverlay();
    const keys = ['height', 'flexDirection', 'alignItems', 'justifyContent', 'padding', 'gap'];
    const saved = {};
    for (const key of keys) saved[key] = overlay.style[key];
    state.overlay = overlay;
    state.savedOverlay = saved;
  }

  function prepareOverlay(overlay) {
    saveOverlay(overlay);
    overlay.style.height = 'auto';
    overlay.style.flexDirection = 'column';
    overlay.style.alignItems = 'stretch';
    overlay.style.justifyContent = 'flex-start';
    overlay.style.padding = '6px 8px 4px';
    overlay.style.gap = '2px';

    const main = overlay.closest('main') || findMain();
    const list = main ? findMessageList(main) : null;
    if (list) {
      if (state.list !== list) {
        restoreList();
        state.list = list;
        state.listInline = list.style.paddingTop || '';
        state.listBase = parseFloat(getComputedStyle(list).paddingTop) || 56;
      }
      const extra = Math.max(0, (overlay.getBoundingClientRect().height || 52) - 52);
      list.style.paddingTop = (state.listBase + extra) + 'px';
    }
  }

  function restoreOverlay() {
    if (state.overlay && state.savedOverlay) {
      const saved = state.savedOverlay;
      for (const key of Object.keys(saved)) state.overlay.style[key] = saved[key];
    }
    state.overlay = null;
    state.savedOverlay = null;
  }

  function restoreList() {
    if (state.list) state.list.style.paddingTop = state.listInline;
    state.list = null;
    state.listInline = '';
    state.listBase = null;
  }

  function removeNode() {
    const node = state.wrap || state.node;
    if (node && node.parentElement) node.parentElement.removeChild(node);
    // 清理旧版本可能残留在对话页头部/输入框上方的入口
    try {
      document.querySelectorAll('#ecq-mem-entry-wrap').forEach((el) => {
        if (el !== node) el.remove();
      });
    } catch (_) {}
    state.emptyRoot = null;
  }

  function hide() {
    if (state.missCount < 3 && state.wrap && state.wrap.isConnected) return;
    removeNode();
    restoreOverlay();
    restoreList();
  }

  function update() {
    if (state.checking) return;
    const miss = () => {
      state.missCount = (state.missCount || 0) + 1;
      if (state.missCount >= 3) hide();
    };
    if (!isChatPage()) { miss(); return; }
    const main = findMain();
    if (!main) { miss(); return; }

    const emptyRoot = findEmptyRoot(main);
    // 入口只在「新建对话」空页面显示；已有对话页不再向头部/输入框上方注入任何按钮
    if (!emptyRoot) { miss(); return; }

    state.missCount = 0;
    state.checking = true;
    try {
      const wrap = buildWrap();
      restoreOverlay();
      restoreList();
      wrap.className = 'ecq-mem-entry-wrap ecq-mem-entry-wrap--empty';
      // 平台 React 会周期性重渲染。只要节点还在文档里，就绝不重复搬动；
      // 只有被平台真正移除后才重新插入，避免入口每 700ms 闪一次。
      if (!wrap.isConnected) {
        emptyRoot.insertBefore(wrap, emptyRoot.firstChild);
        state.emptyRoot = emptyRoot;
      }
      updateLabel();
      loadIdentity();
    } finally {
      state.checking = false;
    }
  }

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== 'session-updated') return;
      state.identity = msg.payload || null;
      updateLabel();
    });
  } catch (_) {}

  function start() {
    update();
    setInterval(update, 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
