/* ECQ 本地记忆 v2 · background service worker
 * 不修改服务端；所有记忆只存在本机 IndexedDB。
 * 命名空间：acct:<accountId>:agent:<agentId> / machine:<machineId>:agent:<agentId>
 * 账号优先；未登录用本机；跨账号绝不自动复制。
 */
const DB_NAME = 'ecq_memory';
const DB_VERSION = 2;
const SOURCE_BG = 'ecq-mem-bg';
const SOURCE_PAGE = 'ecq-mem-page';
const SOURCE_UI = 'ecq-mem-ui';
const ORIGIN = 'https://chat.echenqi.cn';
const CORE_KEYS = ['姓名','城市','行业','机构','门店','主打项目','目标客户','平台','内容风格','禁忌','当前目标','沟通偏好','业务范围'];
const MERGE_KEYS = ['平台','主打项目','目标客户','业务范围','标签'];
const KINDS = ['profile','fact','preference','project','todo','decision','summary'];
const SETTINGS_VERSION = 4;
const DEFAULT_SETTINGS = {
  observeOnly: false,
  autoSummarize: true,
  useLocalAI: true,
  machineFallback: true,
  shareGlobal: false,
  injectMode: 'prefix',
  injectChars: 1600,
  maxItems: 16,
  minUserChars: 6,
  maxConversationChars: 8000,
  localAIUrl: 'http://127.0.0.1:8080/v1/chat/completions',
  localAIModel: 'D:\\models\\qwen2.5-vl-7b\\Qwen2.5-VL-7B-Instruct-Q4_K_M.gguf',
  localAITimeoutMs: 120000
};

let dbPromise = null;
let session = { token: '', accountId: '', name: '', username: '', role: '', at: 0 };
let settingsCache = null;
let machineIdCache = '';
let debugRing = [];
let pageDebug = [];
let debugPersistTimer = 0;
let initPromise = null;
const DEBUG_BG_KEY = 'debug_bg_v2';
const DEBUG_PAGE_KEY = 'debug_page_v2';
const processing = new Set();

const now = () => Date.now();
const clamp = (n, a, b) => Math.max(a, Math.min(b, Number(n) || 0));
const cut = (s, n) => String(s == null ? '' : s).slice(0, n || 4000);
const clean = (s, n) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, n || 4000);
const safeJson = (s) => { try { return JSON.parse(s); } catch (_) { return null; } };
const hash32 = (s) => { let h = 2166136261; const t = String(s || ''); for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
const norm = (s) => String(s || '').toLowerCase().replace(/[\s，。；、,.!?！？:：\-—_（）()【】\[\]\"'“”‘’]/g, '');
const uniq = (arr) => Array.from(new Set((arr || []).filter(Boolean)));
const pad2 = (n) => (n < 10 ? '0' : '') + n;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function dateKey(ts) { const d = new Date(ts || now()); return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + ':' + pad2(d.getSeconds()); }
function dbg(kind, data) { const item = { ts: now(), kind, data: data || {} }; debugRing.push(item); if (debugRing.length > 300) debugRing.shift(); persistDebugSoon(); }
function debugArea() { try { if (chrome.storage && chrome.storage.session) return chrome.storage.session; } catch (_) {} return chrome.storage.local; }
function debugDedupe(list) {
  const seen = new Set();
  const out = [];
  for (const x of list || []) {
    if (!x || typeof x !== 'object') continue;
    let tail = '';
    try { tail = JSON.stringify(x.data || {}).slice(0, 120); } catch (_) {}
    const k = String(x.ts || 0) + '|' + String(x.kind || '') + '|' + tail;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(x);
  }
  return out;
}
async function persistDebugNow() {
  try { await debugArea().set({ [DEBUG_BG_KEY]: debugRing.slice(-200), [DEBUG_PAGE_KEY]: pageDebug.slice(-300) }); } catch (_) {}
}
function persistDebugSoon() {
  if (debugPersistTimer) return;
  debugPersistTimer = setTimeout(() => { debugPersistTimer = 0; void persistDebugNow(); }, 300);
}
async function loadDebugPersist() {
  try {
    const o = await debugArea().get([DEBUG_BG_KEY, DEBUG_PAGE_KEY]);
    const b = Array.isArray(o && o[DEBUG_BG_KEY]) ? o[DEBUG_BG_KEY] : [];
    const p = Array.isArray(o && o[DEBUG_PAGE_KEY]) ? o[DEBUG_PAGE_KEY] : [];
    debugRing = debugDedupe(debugRing.concat(b)).slice(-300);
    pageDebug = debugDedupe(pageDebug.concat(p)).slice(-300);
  } catch (_) {}
}

/* ---------------- IndexedDB ---------------- */
function ensureIndex(store, name, keyPath, opts) { try { if (!store.indexNames.contains(name)) store.createIndex(name, keyPath, opts || { unique: false }); } catch (_) {} }
function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      const tx = req.transaction;
      let mem;
      if (!db.objectStoreNames.contains('memories')) mem = db.createObjectStore('memories', { keyPath: 'id' });
      else mem = tx.objectStore('memories');
      ensureIndex(mem, 'ns', 'ns');
      ensureIndex(mem, 'ns_key', ['ns','key']);
      ensureIndex(mem, 'updatedAt', 'updatedAt');
      ensureIndex(mem, 'status', 'status');
      ensureIndex(mem, 'scope', 'scope');
      ensureIndex(mem, 'agentId', 'agentId');
      ensureIndex(mem, 'accountId', 'accountId');
      ensureIndex(mem, 'machineId', 'machineId');
      ensureIndex(mem, 'account_agent', ['accountId','agentId']);
      ensureIndex(mem, 'machine_agent', ['machineId','agentId']);
      let conv;
      if (!db.objectStoreNames.contains('conversations')) conv = db.createObjectStore('conversations', { keyPath: 'id' });
      else conv = tx.objectStore('conversations');
      ensureIndex(conv, 'agentId', 'agentId');
      ensureIndex(conv, 'updatedAt', 'updatedAt');
      ensureIndex(conv, 'summaryStatus', 'summaryStatus');
      ensureIndex(conv, 'accountId', 'accountId');
      ensureIndex(conv, 'machineId', 'machineId');
      ensureIndex(conv, 'scope', 'scope');
      ensureIndex(conv, 'ns', 'ns');
      ensureIndex(conv, 'account_agent', ['accountId','agentId']);
      ensureIndex(conv, 'machine_agent', ['machineId','agentId']);
      let turns;
      if (!db.objectStoreNames.contains('turns')) turns = db.createObjectStore('turns', { keyPath: 'id' });
      else turns = tx.objectStore('turns');
      ensureIndex(turns, 'conversationId', 'conversationId');
      ensureIndex(turns, 'agentId', 'agentId');
      ensureIndex(turns, 'status', 'status');
      ensureIndex(turns, 'startedAt', 'startedAt');
      ensureIndex(turns, 'ns', 'ns');
      ensureIndex(turns, 'accountId', 'accountId');
      ensureIndex(turns, 'machineId', 'machineId');
      ensureIndex(turns, 'account_agent', ['accountId','agentId']);
      if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'k' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}
async function idbGet(store, key) { const db = await openDB(); return new Promise((res, rej) => { const tx = db.transaction(store, 'readonly'); const r = tx.objectStore(store).get(key); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
async function idbPut(store, value) { const db = await openDB(); return new Promise((res, rej) => { const tx = db.transaction(store, 'readwrite'); const r = tx.objectStore(store).put(value); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
async function idbDelete(store, key) { const db = await openDB(); return new Promise((res, rej) => { const tx = db.transaction(store, 'readwrite'); const r = tx.objectStore(store).delete(key); r.onsuccess = () => res(true); r.onerror = () => rej(r.error); }); }
async function idbAll(store) { const db = await openDB(); return new Promise((res, rej) => { const tx = db.transaction(store, 'readonly'); const r = tx.objectStore(store).getAll(); r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error); }); }
async function idbByIndex(store, index, range) { const db = await openDB(); return new Promise((res, rej) => { const tx = db.transaction(store, 'readonly'); const r = tx.objectStore(store).index(index).getAll(range); r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error); }); }
async function metaGet(k) { const r = await idbGet('meta', k); return r ? r.v : null; }
async function metaPut(k, v) { return idbPut('meta', { k, v, at: now() }); }
async function walkStore(store, fn) { const rows = await idbAll(store); for (const r of rows) { try { await fn(r); } catch (_) {} } return rows.length; }

/* ---------------- 身份与设置 ---------------- */
function parseNs(ns) { const m = String(ns || '').match(/^(acct|machine):([^:]+):agent:(.*)$/); if (!m) return null; return { scope: m[1], id: m[2], agentId: m[3] || '__global__' }; }
function nsMake(scope, id, agentId) { return String(scope) + ':' + String(id || '') + ':agent:' + String(agentId || '__global__'); }
function normalizeAgentId(raw) { const s = clean(raw, 120).replace(/:/g, '_'); return s || 'unknown'; }
function normalizeAccountId(raw) {
  let s = clean(raw, 180);
  if (!s) return '';
  if (/^(anon|anonymous|unknown|guest|游客|none|null|undefined|0)$/i.test(s)) return '';
  if (/^id_/i.test(s)) { const t = s.slice(3).replace(/[^\w.\-]/g, '').slice(0, 100); return t ? 'id_' + t : 'u_' + hash32(s.toLowerCase()); }
  if (/^u_/i.test(s)) { const t = s.slice(2).replace(/[^\w.\-]/g, '').slice(0, 100); return t ? 'u_' + t : 'u_' + hash32(s.toLowerCase()); }
  const safe = s.replace(/[^\w.\-]/g, '').slice(0, 100);
  if (safe) return 'id_' + safe;
  return 'u_' + hash32(s.toLowerCase());
}
function nsOf(ident, agentId) { return nsMake(ident.scope, ident.scope === 'acct' ? ident.accountId : ident.machineId, normalizeAgentId(agentId)); }
function currentIdentity() { const accountId = session.accountId || ''; return { accountId, machineId: machineIdCache, scope: accountId ? 'acct' : 'machine', name: session.name || '', username: session.username || '', role: session.role || '', loggedIn: !!accountId }; }
function accountIdFromUser(u) {
  if (!u || typeof u !== 'object') return '';
  const raw = u.id || u._id || u.userId || u.uid || u.sub || '';
  if (raw) return normalizeAccountId(raw);
  const un = clean(u.username || u.name || u.nickname || '', 80);
  return un ? 'u_' + hash32(un.toLowerCase()) : '';
}
function userDisplayName(u) { if (!u) return ''; return clean(u.name || u.nickname || u.displayName || u.username || '', 60); }
async function loadSession() { try { const o = await chrome.storage.local.get('session_public_v2'); const s = o && o.session_public_v2; if (s && s.accountId) session = Object.assign({ token: '' }, s, { accountId: normalizeAccountId(s.accountId) }); } catch (_) {} }
async function saveSession() { try { await chrome.storage.local.set({ session_public_v2: { accountId: session.accountId, name: session.name, username: session.username, role: session.role, at: session.at } }); } catch (_) {} }
async function clearSession() { session = { token: '', accountId: '', name: '', username: '', role: '', at: now() }; try { await chrome.storage.local.remove('session_public_v2'); } catch (_) {} dbg('session-clear', {}); broadcast({ type: 'session-updated', payload: currentIdentity() }); }
async function updateSessionFromUser(u) {
  const id = accountIdFromUser(u);
  if (!id) { await clearSession(); return currentIdentity(); }
  session = { token: session.token || '', accountId: id, name: userDisplayName(u), username: clean(u && (u.username || ''), 80), role: clean(u && (u.role || ''), 20), at: now() };
  await saveSession();
  dbg('session-updated', { accountId: id, name: session.name });
  broadcast({ type: 'session-updated', payload: currentIdentity() });
  return currentIdentity();
}
async function applyAuth(p) {
  const id = normalizeAccountId(p && p.accountId) || (p && p.username ? 'u_' + hash32(String(p.username).toLowerCase()) : '');
  if (!id) { await clearSession(); return { ok: true, loggedOut: true }; }
  const changed = id !== session.accountId;
  session = { token: cut(p && p.token, 4096), accountId: id, name: clean(p && p.name, 60), username: clean(p && p.username, 80), role: clean(p && p.role, 20), at: now() };
  await saveSession();
  dbg('auth-ok', { accountId: id, name: session.name, changed });
  broadcast({ type: 'session-updated', payload: currentIdentity() });
  refreshBadge();
  return { ok: true, identity: currentIdentity(), changed };
}
function resolveIdentity(p) {
  let accountId = normalizeAccountId(p && p.accountId);
  if (!accountId && p && p.user) accountId = accountIdFromUser(p.user);
  if (!accountId && !(p && p.loggedOut) && !(p && p.accountKnown === true)) accountId = session.accountId || '';
  return { accountId, machineId: machineIdCache, scope: accountId ? 'acct' : 'machine' };
}
async function getMachineId() {
  if (machineIdCache) return machineIdCache;
  try { const o = await chrome.storage.local.get('machine_id_v2'); if (o && o.machine_id_v2) { machineIdCache = String(o.machine_id_v2); return machineIdCache; } } catch (_) {}
  let id = '';
  try { const a = new Uint8Array(12); crypto.getRandomValues(a); id = 'm_' + Array.from(a).map((x) => x.toString(16).padStart(2, '0')).join(''); } catch (_) { id = 'm_' + hash32(String(navigator.userAgent) + '|' + now()); }
  machineIdCache = id;
  try { await chrome.storage.local.set({ machine_id_v2: id }); } catch (_) {}
  return id;
}
async function getSettings() {
  if (settingsCache) return settingsCache;
  let stored = {};
  try { const o = await chrome.storage.local.get('settings_v2'); stored = (o && o.settings_v2) || {}; } catch (_) {}
  const storedVersion = Number(stored.settingsVersion) || 0;
  const explicit = stored.settingsExplicit === true || storedVersion >= SETTINGS_VERSION;
  const patch = {};
  if (storedVersion < SETTINGS_VERSION) {
    patch.machineFallback = DEFAULT_SETTINGS.machineFallback;
    patch.shareGlobal = DEFAULT_SETTINGS.shareGlobal;
  }
  if (!explicit && storedVersion < SETTINGS_VERSION) {
    patch.observeOnly = DEFAULT_SETTINGS.observeOnly;
  }
  const next = Object.assign({}, DEFAULT_SETTINGS, stored, patch, { settingsVersion: SETTINGS_VERSION });
  settingsCache = next;
  if (!explicit || storedVersion < SETTINGS_VERSION) {
    try { await chrome.storage.local.set({ settings_v2: next }); } catch (_) {}
  }
  return settingsCache;
}
async function setSettings(patch) {
  const st = await getSettings();
  const allowed = Object.keys(DEFAULT_SETTINGS);
  const next = Object.assign({}, st);
  for (const k of allowed) if (patch && Object.prototype.hasOwnProperty.call(patch, k)) next[k] = patch[k];
  next.injectChars = clamp(next.injectChars, 200, 8000);
  next.maxItems = clamp(next.maxItems, 4, 60);
  next.minUserChars = clamp(next.minUserChars, 1, 200);
  next.maxConversationChars = clamp(next.maxConversationChars, 1000, 30000);
  next.localAITimeoutMs = clamp(next.localAITimeoutMs, 5000, 300000);
  next.settingsVersion = SETTINGS_VERSION;
  next.settingsExplicit = true;
  settingsCache = next;
  try { await chrome.storage.local.set({ settings_v2: next }); } catch (_) {}
  broadcast({ type: 'settings-changed', payload: next });
  return next;
}
async function ensureIdentityReady() { if (!machineIdCache) await getMachineId(); if (!session.at) await loadSession(); return currentIdentity(); }

/* ---------------- 记忆读写 ---------------- */
function memoryId(ns, key, value) { return 'm_' + hash32(ns + '|' + key + '|' + norm(value)); }
function normalizeKind(kind, key, value) {
  const k = clean(kind, 20);
  if (KINDS.includes(k)) return k;
  const s = String(key || '') + ' ' + String(value || '');
  if (/(姓名|城市|行业|机构|门店|年龄|性别|身份)/.test(key || '')) return 'profile';
  if (/(偏好|风格|语气|沟通)/.test(s)) return 'preference';
  if (/(项目|产品|业务|服务)/.test(key || '')) return 'project';
  if (/(目标|计划|待办|下一步|想要|打算)/.test(s)) return 'todo';
  if (/(决定|确定|已选|采用)/.test(s)) return 'decision';
  if (/(摘要|总结)/.test(s)) return 'summary';
  return 'fact';
}
function mergeValues(values) { const parts = []; for (const v of values) for (const p of String(v || '').split(/[；;、,，]/)) if (p.trim()) parts.push(p.trim()); const u = uniq(parts); return u.join('、').slice(0, 240); }
async function findRows(ns, key) { try { return await idbByIndex('memories', 'ns_key', IDBKeyRange.only([ns, key])); } catch (_) { return []; } }
async function rowsForNs(ns, includeCandidates) { try { return (await idbByIndex('memories', 'ns', IDBKeyRange.only(ns))).filter((r) => r.status === 'active' || (includeCandidates && r.status === 'candidate')); } catch (_) { return []; } }
async function upsertMemory(input) {
  const scope = input.scope === 'machine' ? 'machine' : 'acct';
  const accountId = scope === 'acct' ? normalizeAccountId(input.accountId) : '';
  const machineId = scope === 'machine' ? String(input.machineId || '') : '';
  if (scope === 'acct' && !accountId) return null;
  if (scope === 'machine' && !machineId) return null;
  const agentId = normalizeAgentId(input.agentId || '__global__');
  const ns = nsMake(scope, scope === 'acct' ? accountId : machineId, agentId);
  const key = clean(input.key, 40);
  let value = clean(input.value, 320);
  if (!key || !value || value.length < 2) return null;
  const kind = normalizeKind(input.kind, key, value);
  const ts = now();
  const conf = clamp(input.confidence == null ? 0.85 : input.confidence, 0.1, 1);
  const imp = clamp(input.importance == null ? 0.7 : input.importance, 0.05, 1);
  const rows = await findRows(ns, key);
  const active = rows.filter((r) => r.status === 'active');
  const candidates = rows.filter((r) => r.status === 'candidate');
  let mergedValue = value;
  if (MERGE_KEYS.includes(key) && active.length) {
    const combined = mergeValues(active.map((r) => r.value).concat([value]));
    if (combined && combined.length <= 240 && combined.length >= value.length) mergedValue = combined;
  }
  const same = rows.find((r) => (r.status === 'active' || r.status === 'candidate') && norm(r.value) === norm(mergedValue));
  const turnId = clean(input.turnId, 160);
  if (same) {
    const ev0 = Array.isArray(same.evidenceTurns) ? same.evidenceTurns.slice() : [];
    const isNewEvidence = !turnId || !ev0.includes(turnId);
    if (isNewEvidence) {
      const prevConf = Number(same.confidence) || 0;
      same.confidence = clamp(Math.max(prevConf, conf) + 0.06, 0.1, 1);
      same.confirmCount = (Number(same.confirmCount) || 0) + 1;
      same.lastConfirmedAt = ts;
      if (turnId) ev0.push(turnId);
      same.evidenceTurns = ev0.slice(-50);
    }
    same.importance = Math.max(Number(same.importance) || 0, imp);
    same.updatedAt = ts;
    same.value = mergedValue;
    same.kind = kind;
    same.sourceAgent = clean(input.sourceAgent || same.sourceAgent || '', 80);
    same.sourceAgentName = clean(input.sourceAgentName || same.sourceAgentName || '', 80);
    same.sourceConversation = clean(input.sourceConversation || same.sourceConversation || '', 160);
    same.tags = uniq((same.tags || []).concat(input.tags || [])).slice(0, 12);
    if (same.status === 'candidate' && isNewEvidence) {
      const best = active.slice().sort((a,b) => (Number(b.confidence)||0)-(Number(a.confidence)||0))[0];
      if (!best || same.confidence >= (Number(best.confidence)||0) - 0.05 || (Number(same.confirmCount)||0) >= 2) {
        for (const r of active) if (r.id !== same.id) { r.status = 'superseded'; r.supersededAt = ts; await idbPut('memories', r); }
        same.status = 'active';
      }
    }
    await idbPut('memories', same);
    return same;
  }
  const bestOld = active.slice().sort((a,b) => (Number(b.confidence)||0)-(Number(a.confidence)||0))[0];
  let status = 'active';
  if (bestOld) {
    const bestConf = Number(bestOld.confidence) || 0;
    if (conf >= bestConf + 0.15) {
      for (const r of active) { r.status = 'superseded'; r.supersededAt = ts; await idbPut('memories', r); }
    } else if (conf >= bestConf - 0.10) {
      status = 'candidate';
    } else {
      dbg('memory-ignored', { key, value: value.slice(0,60), conf, best: bestConf });
      return null;
    }
  }
  const rec = {
    id: memoryId(ns, key, mergedValue),
    accountId, machineId, scope, agentId, ns, kind, key, value: mergedValue,
    confidence: conf, importance: imp,
    confirmCount: 1, evidenceTurns: turnId ? [turnId] : [],
    useCount: 0, lastUsedAt: 0, lastConfirmedAt: ts,
    sourceAgent: clean(input.sourceAgent || agentId, 80),
    sourceAgentName: clean(input.sourceAgentName || '', 80),
    sourceConversation: clean(input.sourceConversation || '', 160),
    tags: uniq(input.tags || []).slice(0, 12),
    status, createdAt: ts, updatedAt: ts
  };
  await idbPut('memories', rec);
  return rec;
}
async function touchMemories(rows) { const ts = now(); for (const r of rows) { r.lastUsedAt = ts; r.useCount = (Number(r.useCount) || 0) + 1; try { await idbPut('memories', r); } catch (_) {} } }
function tokenize(s) { const out = new Set(); const t = String(s || '').toLowerCase(); for (const w of (t.match(/[a-z0-9_]{2,}/g) || [])) out.add(w); const cn = t.replace(/[^\u4e00-\u9fa5]+/g, ' '); for (const seg of cn.split(/\s+/)) { if (!seg) continue; if (seg.length <= 4) out.add(seg); for (let i = 0; i < seg.length - 1; i++) out.add(seg.slice(i, i + 2)); } return out; }
function scoreMemory(m, qt) {
  const mt = tokenize((m.key || '') + ' ' + (m.value || '') + ' ' + (m.tags || []).join(' '));
  let hit = 0; for (const t of qt) if (mt.has(t)) hit++;
  const overlap = qt.size ? hit / qt.size : 0;
  const ageH = Math.max(0, (now() - (m.updatedAt || 0)) / 3600000);
  const recency = 1 / (1 + ageH / 240);
  const use = Math.min(Number(m.useCount) || 0, 20) / 20;
  return overlap * 0.42 + (Number(m.importance)||0) * 0.22 + (Number(m.confidence)||0) * 0.18 + recency * 0.12 + use * 0.06;
}
function dedupeRowsByKey(rows) {
  const byKey = new Map();
  for (const r of (rows || [])) {
    const k = String(r.key || '').trim();
    if (!k) continue;
    const prev = byKey.get(k);
    if (!prev) { byKey.set(k, r); continue; }
    const pc = Number(prev.confidence) || 0, rc = Number(r.confidence) || 0;
    const pu = Number(prev.updatedAt) || 0, ru = Number(r.updatedAt) || 0;
    if (rc > pc + 1e-9 || (Math.abs(rc - pc) <= 1e-9 && ru > pu)) byKey.set(k, r);
  }
  return Array.from(byKey.values());
}
async function retrieve(ident, agentId, query) {
  const st = await getSettings();
  const aid = normalizeAgentId(agentId);
  const primaryNs = nsOf(ident, aid);
  const globalNs = nsOf(ident, '__global__');
  const canGlobal = !!st.shareGlobal && aid !== '__global__';
  const own = dedupeRowsByKey(await rowsForNs(primaryNs, false));
  const shared = canGlobal ? dedupeRowsByKey(await rowsForNs(globalNs, false)) : [];
  const ownKeys = new Set(own.map((r) => String(r.key || '')));
  let rows = own.concat(shared.filter((r) => !ownKeys.has(String(r.key || ''))));
  let usedFallback = false;
  if (!own.length && ident.scope === 'acct' && st.machineFallback) {
    const mIdent = { accountId: '', machineId: ident.machineId, scope: 'machine' };
    const mOwn = dedupeRowsByKey(await rowsForNs(nsOf(mIdent, aid), false));
    const mShared = canGlobal ? dedupeRowsByKey(await rowsForNs(nsOf(mIdent, '__global__'), false)) : [];
    const mKeys = new Set(mOwn.map((r) => String(r.key || '')));
    const mRows = mOwn.concat(mShared.filter((r) => !mKeys.has(String(r.key || ''))));
    if (mRows.length) {
      const have = new Set(rows.map((r) => String(r.key || '')));
      rows = rows.concat(mRows.filter((r) => !have.has(String(r.key || ''))));
      usedFallback = true;
    }
  }
  const seen = new Set(); rows = rows.filter((r) => { const id = String(r.id || ''); if (id && seen.has(id)) return false; if (id) seen.add(id); return true; });
  const qt = tokenize(query || '');
  const scored = rows.map((r) => ({ r, s: scoreMemory(r, qt) })).sort((a,b) => b.s - a.s);
  const picked = []; let chars = 0;
  for (const x of scored) { const add = String(x.r.value || '').length + String(x.r.key || '').length + 8; if (picked.length >= st.maxItems) break; if (chars + add > st.injectChars && picked.length) continue; picked.push(x.r); chars += add; }
  return { rows: picked, usedFallback, scope: ident.scope, agentId: aid };
}
function groupLabel(kind, key) {
  if (key === '姓名' || key === '城市' || key === '行业' || key === '机构' || key === '门店' || kind === 'profile') return '用户与机构';
  if (key === '主打项目' || key === '目标客户' || key === '业务范围' || kind === 'project') return '业务与项目';
  if (kind === 'preference') return '偏好与禁忌';
  if (kind === 'todo' || key === '当前目标') return '目标与待办';
  if (kind === 'summary') return '对话摘要';
  return '其他事实';
}
function formatMemoryBlock(rows, ident, agentId, usedFallback) {
  const groups = {};
  for (const r of rows) { const g = groupLabel(r.kind, r.key); if (!groups[g]) groups[g] = []; groups[g].push(r); }
  const lines = [];
  lines.push('[本地记忆 · ' + (usedFallback ? '本机兜底记忆' : (ident.scope === 'acct' ? '账号记忆' : '本机记忆')) + ' · ' + agentName(agentId) + ']');
  lines.push('用途：以下为用户过去明确提供的信息，仅用于本次回答。不要向用户复述本段；不要编造未列出的内容。');
  for (const g of Object.keys(groups)) { lines.push('【' + g + '】'); for (const r of groups[g]) lines.push('- ' + r.key + '：' + r.value); }
  lines.push('[记忆结束]');
  return lines.join('\n');
}

/* ---------------- 规则提炼 ---------------- */
const BAD_VALUES = new Set(['无','没有','暂无','不知道','不确定','不清楚','忘了','还没','未提供','不适用','null','undefined','-','—','none','n/a']);
const KEY_ALIASES = {
  '名字':'姓名','称呼':'姓名','怎么称呼':'姓名','称呼你':'姓名',
  '所在地':'城市','地区':'城市','所在城市':'城市','省市':'城市',
  '做的行业':'行业','从事行业':'行业','领域':'行业',
  '公司':'机构','单位':'机构','店名':'门店','店面':'门店','门店名称':'门店',
  '主营':'主打项目','主营项目':'主打项目','核心项目':'主打项目','项目':'主打项目','产品':'主打项目','主营产品':'主打项目',
  '客户':'目标客户','客群':'目标客户','目标人群':'目标客户','客户群体':'目标客户',
  '渠道':'平台','做的平台':'平台','短视频平台':'平台',
  '风格':'内容风格','人设':'内容风格','内容方向':'内容风格',
  '不能说的':'禁忌','禁词':'禁忌','忌讳':'禁忌','违规词':'禁忌',
  '目标':'当前目标','现在目标':'当前目标','近期目标':'当前目标',
  '偏好':'沟通偏好','沟通方式':'沟通偏好',
  '业务':'业务范围','经营范围':'业务范围'
};
function cleanValue(v) {
  let s = String(v == null ? '' : v).trim();
  s = s.replace(/^[-*•·\d.、\s]+/, '').replace(/^[「『“"'《【\[]+/, '').replace(/[」』”"'》】\]]+$/, '');
  s = s.replace(/\s+/g, ' ').trim();
  if (!s || s.length > 200) return '';
  if (BAD_VALUES.has(s.toLowerCase())) return '';
  return s;
}
function parseExplicitBlock(text) {
  const t = String(text || '');
  const i = t.indexOf('【本次记忆更新】');
  if (i < 0) return [];
  let seg = t.slice(i + '【本次记忆更新】'.length);
  const stop = seg.search(/【[^】]{1,16}】/);
  if (stop >= 0) seg = seg.slice(0, stop);
  const out = [];
  for (const line of seg.split(/\r?\n/)) {
    const m = line.match(/^\s*[-*•]?\s*([^：:]{1,16})[：:]\s*(.+?)\s*$/);
    if (!m) continue;
    const key = KEY_ALIASES[m[1].trim()] || m[1].trim();
    const value = cleanValue(m[2]);
    if (!key || !value) continue;
    if (/^(无|没有|暂无)$/.test(value)) continue;
    out.push({ key, value, kind: normalizeKind('', key, value) });
  }
  return out;
}
function extractHeuristic(text) {
  const t = String(text || '').replace(/\s+/g, ' ');
  const out = [];
  const add = (key, value) => { const v = cleanValue(value); if (key && v) out.push({ key, value: v, kind: normalizeKind('', key, v) }); };
  let m;
  if ((m = t.match(/(?:我叫|我的名字是|我是|叫我)([\u4e00-\u9fa5A-Za-z]{1,8})(?:[，,。；;\s]|$)/))) add('姓名', m[1]);
  if ((m = t.match(/(?:我在|我住在|坐标|所在地是|城市是)([\u4e00-\u9fa5]{2,10}?)(?:[，,。；;的\s]|$)/))) add('城市', m[1]);
  if ((m = t.match(/(?:我是做|我从事|我的行业是|行业是)([\u4e00-\u9fa5A-Za-z]{2,20}?)(?:[，,。；;的\s]|$)/))) add('行业', m[1]);
  if ((m = t.match(/(?:我的店叫|店名叫|门店叫|我们店叫|我的机构叫|机构叫|公司叫)([\u4e00-\u9fa5A-Za-z0-9]{2,30}?)(?:[，,。；;\s]|$)/))) add('门店', m[1]);
  if ((m = t.match(/(?:主打|主营|主要做|核心项目是|特色项目是)([\u4e00-\u9fa5A-Za-z0-9、，,和及]{2,40}?)(?:[。；;\s]|$)/))) add('主打项目', m[1]);
  if ((m = t.match(/(?:我的客户是|客户主要是|面向|目标客户是)([\u4e00-\u9fa5A-Za-z0-9、，,和及]{2,40}?)(?:[。；;\s]|$)/))) add('目标客户', m[1]);
  if ((m = t.match(/(?:做的平台是|主要在|平台是)(抖音|快手|视频号|小红书|公众号|B站|知乎|微博|百家号)/))) add('平台', m[1]);
  if ((m = t.match(/(?:内容风格|人设|风格)(?:是|走|做)([\u4e00-\u9fa5A-Za-z]{2,24}?)(?:[，,。；;\s]|$)/))) add('内容风格', m[1]);
  if ((m = t.match(/(?:不能说|禁忌|不能提|不要提)([\u4e00-\u9fa5A-Za-z0-9、，,和及]{2,60}?)(?:[。；;\s]|$)/))) add('禁忌', m[1]);
  if ((m = t.match(/(?:我的目标是|当前目标|现在主要想|这30天想)([\u4e00-\u9fa5A-Za-z0-9、，,和及]{2,60}?)(?:[。；;\s]|$)/))) add('当前目标', m[1]);
  return out;
}
function normalizeAIMemory(obj) {
  if (!obj || typeof obj !== 'object') return [];
  const arr = Array.isArray(obj) ? obj : (Array.isArray(obj.items) ? obj.items : []);
  const out = [];
  for (const it of arr) {
    if (!it || typeof it !== 'object') continue;
    let key = clean(String(it.key || it.k || '', 24));
    if (!key) continue;
    key = KEY_ALIASES[key] || key;
    const value = cleanValue(it.value || it.v || '');
    if (!value) continue;
    const kind = KINDS.includes(String(it.kind || '')) ? String(it.kind) : normalizeKind('', key, value);
    out.push({ key, value, kind });
  }
  return dedupeMemories(out);
}
function parseJsonLoose(s) {
  let t = String(s || '').trim();
  t = t.replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a >= 0 && b > a) t = t.slice(a, b + 1);
  try { return JSON.parse(t); } catch (_) { return null; }
}
function agentName(agentId) {
  const id = normalizeAgentId(agentId);
  if (id === '__global__') return '跨智能体核心画像';
  const hit = agentNames.find((a) => a.id === id);
  return (hit && hit.name) ? hit.name : id;
}
async function aiSummarize(text, ident, agentId) {
  const st = await getSettings();
  if (!st.useLocalAI) return { ok: false, reason: 'local-ai-off' };
  const sys = [
    '你是记忆提取器。只提取用户在本轮对话中明确说过的事实与偏好，以及助手在【本次记忆更新】中列出的条目。',
    '禁止推测、禁止补全、禁止编造。没有就返回空数组。',
    '只输出 JSON：{"items":[{"key":"城市","value":"包头","kind":"profile"}],"summary":"一句话概括本轮"}。',
    'key 优先用：姓名/城市/行业/机构/门店/主打项目/目标客户/平台/内容风格/禁忌/当前目标/沟通偏好/业务范围；其他事实可自拟 2~8 字 key。',
    'kind 取值：profile/fact/preference/project/todo/decision/summary。value 不超过 120 字。'
  ].join('\n');
  const body = {
    model: 'local', temperature: 0.1, max_tokens: 700,
    messages: [{ role: 'system', content: sys }, { role: 'user', content: String(text || '').slice(0, 6000) }]
  };
  const ctrl = new AbortController();
  const timer = setTimeout(() => { try { ctrl.abort(); } catch (_) {} }, Math.max(5000, Number(st.localAITimeoutMs) || 120000));
  try {
    const r = await fetch(st.localAIUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: ctrl.signal });
    if (!r.ok) return { ok: false, reason: 'http-' + r.status };
    const j = await r.json();
    const txt = j && j.choices && j.choices[0] && j.choices[0].message ? j.choices[0].message.content : '';
    const obj = parseJsonLoose(txt);
    if (!obj) return { ok: false, reason: 'bad-json' };
    return { ok: true, items: normalizeAIMemory(obj), summary: clean(String(obj.summary || ''), 240) };
  } catch (e) {
    return { ok: false, reason: String(e && e.name === 'AbortError' ? 'timeout' : (e && e.message) || 'fetch-fail') };
  } finally { clearTimeout(timer); }
}
function dedupeMemories(items) {
  const seen = new Set(); const out = [];
  for (const it of items || []) {
    if (!it || !it.key) continue;
    const k = String(it.key) + '\u0001' + norm(it.value);
    if (seen.has(k)) continue;
    seen.add(k); out.push(it);
  }
  return out;
}
async function applyMemories(ident, agentId, items, source, turnId) {
  let n = 0;
  const list = dedupeMemories(items);
  const aid = normalizeAgentId(agentId);
  const ns = nsOf(ident, aid);
  for (const it of list) {
    try {
      await upsertMemory({ ns, scope: ident.scope, accountId: ident.accountId || '', machineId: ident.machineId || '', agentId: aid, key: it.key, value: it.value, kind: it.kind, source: source || 'manual', turnId: turnId || '', confidence: source === 'explicit' ? 0.95 : (source === 'ai' ? 0.8 : 0.6) });
      n++;
    } catch (_) {}
    if (CORE_KEYS.includes(it.key) && aid !== '__global__') {
      const st = await getSettings();
      if (st.shareGlobal) {
        try {
          await upsertMemory({ ns: nsOf(ident, '__global__'), scope: ident.scope, accountId: ident.accountId || '', machineId: ident.machineId || '', agentId: '__global__', key: it.key, value: it.value, kind: it.kind, source: 'global-' + (source || 'manual'), turnId: turnId || '', confidence: 0.9 });
        } catch (_) {}
      }
    }
  }
  return n;
}

/* ================= 运行层 ================= */
let agentNames = [];
async function loadAgentNames() {
  try {
    const o = await chrome.storage.local.get('agent_names_v2');
    const m = (o && o.agent_names_v2) || {};
    agentNames = Object.keys(m).map((id) => ({ id, name: m[id] })).filter((a) => a.id && a.name);
  } catch (_) { agentNames = []; }
  return agentNames;
}
async function rememberAgentName(id, name) {
  const aid = normalizeAgentId(id); const nm = clean(name, 60);
  if (!aid || aid === 'unknown' || !nm) return;
  const i = agentNames.findIndex((a) => a.id === aid);
  if (i >= 0) { if (agentNames[i].name === nm) return; agentNames[i].name = nm; }
  else agentNames.push({ id: aid, name: nm });
  if (agentNames.length > 400) agentNames = agentNames.slice(-400);
  try {
    const m = {}; for (const a of agentNames) m[a.id] = a.name;
    await chrome.storage.local.set({ agent_names_v2: m });
  } catch (_) {}
}
function broadcast(msg) {
  const m = Object.assign({ source: SOURCE_BG, ts: now() }, msg || {});
  try { chrome.runtime.sendMessage(m).catch(() => {}); } catch (_) {}
  try {
    chrome.tabs.query({ url: ORIGIN + '/*' }, (tabs) => {
      for (const t of tabs || []) { try { chrome.tabs.sendMessage(t.id, m).catch(() => {}); } catch (_) {} }
    });
  } catch (_) {}
}
function scopeKey(ident) { const i = ident || {}; return String(i.scope || 'machine') + ':' + (i.scope === 'acct' ? (i.accountId || '') : (i.machineId || '')); }
function convKeyOf(conversationId, agentId, ident) { return scopeKey(ident) + '|' + normalizeAgentId(agentId) + '|' + String(conversationId || ''); }
function payloadIdentityExplicit(p) {
  if (!p) return false;
  return p.accountKnown === true || p.loggedOut === true || !!p.accountId || !!p.user;
}
function identityFromPayload(p) {
  if (p && p.loggedOut === true) {
    return { accountId: '', machineId: machineIdCache, scope: 'machine' };
  }
  if (p && p.accountKnown === true && !p.accountId && !p.user) {
    return {
      accountId: session.accountId || '',
      machineId: machineIdCache,
      scope: session.accountId ? 'acct' : 'machine'
    };
  }
  return resolveIdentity(p || {});
}
function idMatches(a, b) { return String(a || '') === String(b || ''); }
function turnMatchesPayload(turn, ident, agentId, conversationId) {
  if (!turn) return false;
  if (!idMatches(normalizeAgentId(turn.agentId), normalizeAgentId(agentId))) return false;
  if (!idMatches(turn.conversationId, conversationId)) return false;
  if (String(turn.scope) !== String(ident.scope)) return false;
  if (ident.scope === 'acct') return idMatches(turn.accountId, ident.accountId) && !turn.machineId;
  return idMatches(turn.machineId, ident.machineId) && !turn.accountId;
}
async function migrateV1() {
  try {
    const done = await metaGet('migrated_v2');
    if (done) return { ok: true, skipped: true };
  } catch (_) {}
  let imported = 0;
  try {
    const o = await chrome.storage.local.get(['memories_v1', 'ecq_memories_v1', 'ecq_memories']);
    const arr = (o && (o.memories_v1 || o.ecq_memories_v1 || o.ecq_memories)) || [];
    if (Array.isArray(arr)) {
      for (const it of arr) {
        if (!it || !it.key || !it.value) continue;
        const accountId = normalizeAccountId(it.accountId);
        const machineId = accountId ? '' : String(it.machineId || machineIdCache || '');
        if (!accountId && !machineId) continue;
        const ident = { accountId, machineId, scope: accountId ? 'acct' : 'machine' };
        const aid = normalizeAgentId(it.agentId || 'unknown');
        await upsertMemory({ ns: nsOf(ident, aid), scope: ident.scope, accountId, machineId, agentId: aid, key: clean(it.key, 40), value: clean(it.value, 200), kind: normalizeKind(it.kind, it.key, it.value), source: 'migrated-v1', confidence: 0.7 });
        imported++;
      }
    }
  } catch (_) {}
  try { await metaPut('migrated_v2', { at: now(), imported }); } catch (_) {}
  return { ok: true, imported };
}
function makeTurnId() { return 't_' + now().toString(36) + '_' + Math.random().toString(36).slice(2, 8); }

/* ---------------- 对话落库 ---------------- */
const summarizingIds = new Set();
async function backfillTurnConversation(turn, rawConv, agentId, ident) {
  const oldConvId = String(turn.convId || '');
  const oldRawConv = String(turn.conversationId || '');
  const newConvKey = convKeyOf(rawConv, agentId, ident);
  const newConvId = 'cv_' + hash32(newConvKey);
  if (idMatches(oldRawConv, rawConv) && idMatches(oldConvId, newConvId)) {
    if (turn.convPlaceholder) { turn.convPlaceholder = false; turn.updatedAt = now(); await idbPut('turns', turn); }
    return { moved: false };
  }

  turn.conversationId = rawConv;
  turn.convId = newConvId;
  turn.convKey = newConvKey;
  turn.convPlaceholder = false;
  turn.backfilledAt = now();
  turn.updatedAt = now();
  await idbPut('turns', turn);

  const allTurns = await idbAll('turns').catch(() => []);
  const turnsOf = (cid) => allTurns.filter((t) => idMatches(t.convId, cid));
  const recount = (cid, meta) => {
    const rows = turnsOf(cid);
    const c = Object.assign({ id: cid }, meta || {});
    c.turnCount = rows.length;
    c.messageCount = rows.reduce((n, t) => n + (String(t.userText || '').trim() ? 1 : 0) + (String(t.assistantText || '').trim() ? 1 : 0), 0);
    const us = rows.map((t) => Number(t.startedAt || 0)).filter(Boolean);
    const rs = rows.map((t) => Number(t.completedAt || 0)).filter(Boolean);
    const cs = rows.map((t) => Number(t.createdAt || 0)).filter(Boolean);
    if (us.length) c.lastUserAt = Math.max.apply(null, us);
    if (rs.length) c.lastReplyAt = Math.max.apply(null, rs);
    c.createdAt = cs.length ? Math.min.apply(null, cs) : ((meta && meta.createdAt) || now());
    c.updatedAt = now();
    const done = rows.some((t) => t.status === 'summarized' || t.summarized);
    const pend = rows.some((t) => t.status === 'completed' && !t.summarized);
    if (done) c.summaryStatus = 'done';
    else if (pend) c.summaryStatus = 'pending';
    else if (!c.summaryStatus) c.summaryStatus = 'pending';
    return c;
  };

  const oldConv = (oldConvId && !idMatches(oldConvId, newConvId)) ? await idbGet('conversations', oldConvId).catch(() => null) : null;
  const newPrev = await idbGet('conversations', newConvId).catch(() => null);
  const newMeta = Object.assign({}, newPrev || {}, {
    id: newConvId, conversationId: rawConv, agentId: normalizeAgentId(agentId),
    agentName: (newPrev && newPrev.agentName) || turn.agentName || agentName(agentId),
    ns: turn.ns, scope: turn.scope, accountId: turn.accountId, machineId: turn.machineId,
    convPlaceholder: false
  });
  await idbPut('conversations', recount(newConvId, newMeta));

  if (oldConv && !idMatches(oldConvId, newConvId)) {
    const rest = turnsOf(oldConvId).filter((t) => !idMatches(t.id, turn.id));
    if (!rest.length) {
      await idbDelete('conversations', oldConvId).catch(() => {});
    } else {
      const oldMeta = Object.assign({}, oldConv, { id: oldConvId, mergedInto: newConvId });
      await idbPut('conversations', recount(oldConvId, oldMeta));
    }
  }
  dbg('turn-backfill', { turnId: turn.id, from: oldRawConv, to: rawConv });
  return { moved: true, convId: newConvId };
}
async function storeChatRequest(p) {
  const payload = p || {};
  const agentId = normalizeAgentId(payload.agentId);
  const rawConv = clean(payload.conversationId || '', 120);
  const userText = cut(String(payload.userText || '').trim(), 12000);
  if (!userText) {
    dbg('req-empty-user-text', { preview: String(payload.userText || '').slice(0, 200), keys: Object.keys(payload || {}).slice(0, 24) });
    return { ok: false, reason: 'empty-user-text' };
  }
  const declared = normalizeAccountId(payload.accountId);
  if (declared && session.accountId && declared !== session.accountId) {
    dbg('req-identity-mismatch', { declared, session: session.accountId });
    return { ok: false, reason: 'turn-identity-mismatch' };
  }
  const ident = identityFromPayload(payload);
  if (!ident.accountId && !ident.machineId) await ensureIdentityReady();
  const turnId = clean(payload.turnId || '', 60) || makeTurnId();
  const exist = await idbGet('turns', turnId).catch(() => null);
  if (exist) {
    if (rawConv && !idMatches(exist.conversationId, rawConv) && exist.convPlaceholder) {
      try { await backfillTurnConversation(exist, rawConv, agentId, ident); }
      catch (e) { dbg('turn-backfill-error', { turnId, err: String((e && e.message) || e) }); }
      const fresh = await idbGet('turns', turnId).catch(() => null);
      return { ok: true, turnId, backfilled: true, conversationId: (fresh && fresh.conversationId) || rawConv, ns: (fresh && fresh.ns) || exist.ns, scope: (fresh && fresh.scope) || exist.scope, agentId };
    }
    return { ok: true, turnId, deduped: true, conversationId: exist.conversationId };
  }
  const rawConvId = rawConv || ('c_' + hash32(scopeKey(ident) + '|' + agentId + '|' + turnId));
  const convId = 'cv_' + hash32(convKeyOf(rawConvId, agentId, ident));
  await rememberAgentName(agentId, payload.agentName);
  const ts = Number(payload.startedAt) || now();
  const turn = {
    id: turnId, conversationId: rawConvId, convId, convKey: convKeyOf(rawConvId, agentId, ident),
    agentId, agentName: clean(payload.agentName, 60) || agentName(agentId),
    ns: nsOf(ident, agentId), scope: ident.scope, accountId: ident.accountId || '', machineId: ident.scope === 'machine' ? (ident.machineId || '') : '',
    userText, startedAt: ts, createdAt: now(), status: 'requested', convPlaceholder: !rawConv
  };
  await idbPut('turns', turn);
  const prev = await idbGet('conversations', convId).catch(() => null);
  const conv = Object.assign({ id: convId, conversationId: rawConvId, agentId, agentName: turn.agentName, ns: turn.ns, scope: turn.scope, accountId: turn.accountId, machineId: turn.machineId, createdAt: now(), turnCount: 0, messageCount: 0 }, prev || {});
  conv.turnCount = (Number(conv.turnCount) || 0) + 1;
  conv.messageCount = (Number(conv.messageCount) || 0) + 1;
  conv.lastUserAt = ts; conv.updatedAt = now();
  if (!prev) conv.summaryStatus = 'pending';
  await idbPut('conversations', conv);
  dbg('turn-request', { turnId, agentId, scope: turn.scope, conv: rawConvId });
  return { ok: true, turnId, conversationId: rawConvId, ns: turn.ns, scope: turn.scope, agentId };
}
async function findTurnForComplete(p) {
  const payload = p || {};
  const agentId = normalizeAgentId(payload.agentId);
  const rawConv = clean(payload.conversationId || '', 120);
  const ident = identityFromPayload(payload);
  if (!ident.accountId && !ident.machineId) await ensureIdentityReady();
  const tid = clean(payload.turnId || '', 60);
  if (tid) {
    const t = await idbGet('turns', tid).catch(() => null);
    if (!t) return null;

    if (rawConv && !idMatches(t.conversationId, rawConv)) {
      if (!t.convPlaceholder) {
        dbg('complete-conversation-mismatch', { turnId: tid });
        return null;
      }
      try { await backfillTurnConversation(t, rawConv, agentId, ident); } catch (_) {}
      const t2 = await idbGet('turns', tid).catch(() => null);
      if (!t2) return null;
      if (!turnMatchesPayload(t2, ident, agentId, t2.conversationId)) {
        dbg('complete-identity-mismatch', { turnId: tid });
        return null;
      }
      return t2;
    }

    if (!turnMatchesPayload(t, ident, agentId, t.conversationId)) {
      dbg('complete-identity-mismatch', { turnId: tid });
      return null;
    }

    return t;
  }
  if (!rawConv) return null;
  let rows = [];
  try { rows = await idbByIndex('turns', 'conversationId', IDBKeyRange.only(rawConv)); } catch (_) { return null; }
  const nowTs = now();
  const cand = rows.filter((t) => turnMatchesPayload(t, ident, agentId, rawConv) && t.status === 'requested' && Math.abs(nowTs - Number(t.startedAt || 0)) <= 30 * 60 * 1000);
  cand.sort((a, b) => Number(b.startedAt || 0) - Number(a.startedAt || 0));
  return cand[0] || null;
}
async function storeChatComplete(p) {
  const payload = p || {};
  const reply = cut(String(payload.assistantText || payload.reply || payload.text || '').trim(), 20000);
  if (!reply) return { ok: false, reason: 'empty-reply' };
  let turn = null;
  for (let i = 0; i < 3; i++) {
    turn = await findTurnForComplete(payload).catch(() => null);
    if (turn) break;
    await new Promise((r) => setTimeout(r, i === 0 ? 150 : 250));
  }
  if (!turn) {
    dbg('complete-turn-not-found', { turnId: clean(payload.turnId || '', 60), agentId: normalizeAgentId(payload.agentId), conv: clean(payload.conversationId || '', 120) });
    return { ok: false, reason: 'turn-not-found' };
  }
  if (['aborted', 'abandoned', 'cancelled'].indexOf(String(turn.status || '')) >= 0) return { ok: true, turnId: turn.id, ignored: 'inactive-turn' };
  if (completingIds.has(turn.id)) return { ok: true, turnId: turn.id, ignored: 'in-flight' };
  completingIds.add(turn.id);
  try {
    const old = String(turn.assistantText || '');
    if (old && reply.length <= old.length) return { ok: true, turnId: turn.id, ignored: 'duplicate-or-shorter' };
    turn.assistantText = reply;
    turn.status = turn.status === 'summarized' ? 'summarized' : 'completed';
    turn.completedAt = now();
    turn.updatedAt = now();
    await idbPut('turns', turn);
    const conv = await idbGet('conversations', turn.convId).catch(() => null);
    if (conv) {
      conv.lastReplyAt = now(); conv.updatedAt = now();
      conv.messageCount = (Number(conv.messageCount) || 0) + 1;
      if (conv.summaryStatus !== 'done') conv.summaryStatus = 'pending';
      await idbPut('conversations', conv);
    }
    dbg('turn-complete', { turnId: turn.id, len: reply.length });
    if (!summarizingIds.has(turn.id) && turn.status !== 'summarized') { void summarizeTurn(turn.id); }
    return { ok: true, turnId: turn.id, conversationId: turn.conversationId, status: turn.status };
  } finally { completingIds.delete(turn.id); }
}
const completingIds = new Set();

/* ---------------- 总结 ---------------- */
async function addSummaryMemory(turn, summaryText) {
  const text = clean(summaryText, 400);
  if (!text) return '';
  const key = '对话摘要 ' + String(turn.id || '').slice(-12);
  const ident = { accountId: turn.accountId || '', machineId: turn.machineId || '', scope: turn.scope === 'acct' ? 'acct' : 'machine' };
  await upsertMemory({
    ns: turn.ns, scope: ident.scope, accountId: ident.accountId, machineId: ident.machineId,
    agentId: turn.agentId, key, value: text, kind: 'summary', source: turn.summarySource || 'summary',
    turnId: turn.id, confidence: 0.75
  });
  return key;
}
async function summarizeTurn(turnId) {
  if (!turnId || summarizingIds.has(turnId)) return { ok: false, reason: 'busy' };
  summarizingIds.add(turnId);
  let turn = null;
  try {
    turn = await idbGet('turns', turnId).catch(() => null);
    if (!turn) return { ok: false, reason: 'turn-not-found' };
    if (['aborted', 'abandoned', 'cancelled', 'failed', 'disabled'].indexOf(String(turn.status || '')) >= 0) return { ok: true, skipped: 'inactive-turn', turnId };
    if (turn.status === 'summarized' && turn.summary) return { ok: true, skipped: true, turnId };
    const st = await getSettings();
    if (!st.autoSummarize) {
      turn.status = 'disabled'; turn.updatedAt = now(); await idbPut('turns', turn);
      const c0 = await idbGet('conversations', turn.convId).catch(() => null);
      if (c0) { c0.summaryStatus = 'disabled'; c0.updatedAt = now(); await idbPut('conversations', c0); }
      return { ok: true, skipped: 'auto-summarize-off' };
    }
    turn.status = 'summarizing'; turn.updatedAt = now(); await idbPut('turns', turn);
    const assistant = String(turn.assistantText || '');
    const conv = await idbGet('conversations', turn.convId).catch(() => null);
    if (conv) { conv.summaryStatus = 'running'; conv.updatedAt = now(); await idbPut('conversations', conv); }
    const explicit = parseExplicitBlock(assistant);
    const heur = extractHeuristic(String(turn.userText || '') + '\n' + assistant);
    let ai = { ok: false, items: [], summary: '' };
    if (st.useLocalAI) {
      try { ai = await aiSummarize('用户：' + String(turn.userText || '') + '\n\n助手：' + assistant, { accountId: turn.accountId, machineId: turn.machineId, scope: turn.scope }, turn.agentId); } catch (_) { ai = { ok: false, items: [], summary: '' }; }
    }
    const items = dedupeMemories([].concat(explicit, ai.ok ? ai.items : [], heur));
    const ident = { accountId: turn.accountId || '', machineId: turn.machineId || '', scope: turn.scope === 'acct' ? 'acct' : 'machine' };
    const src = explicit.length ? (ai.ok ? 'mixed' : 'explicit') : (ai.ok ? 'ai' : 'heuristic');
    const n = await applyMemories(ident, turn.agentId, items, src, turn.id);
    let summary = clean(ai.ok ? ai.summary : '', 240);
    if (!summary) {
      const u = clean(turn.userText, 60);
      const a = clean(assistant.replace(/【本次记忆更新】[\s\S]*$/, ''), 90);
      summary = ('用户问：' + u + (a ? '；要点：' + a : '')).slice(0, 240);
    }
    turn.summarized = true; turn.status = 'summarized'; turn.summary = summary;
    turn.summaryAt = now(); turn.summarySource = src; turn.memoryCount = n; turn.updatedAt = now();
    if (items.length) turn.summaryKeys = uniq(items.map((x) => x.key)).slice(0, 20);
    await idbPut('turns', turn);
    await addSummaryMemory(turn, summary);
    const c2 = await idbGet('conversations', turn.convId).catch(() => null);
    if (c2) { c2.summaryStatus = 'done'; c2.lastSummaryAt = turn.summaryAt; c2.summarySource = src; c2.updatedAt = now(); await idbPut('conversations', c2); }
    dbg('summarize-done', { turnId, src, n, ai: ai.ok });
    return { ok: true, turnId, memoryCount: n, source: src };
  } catch (e) {
    try {
      if (turn) { turn.status = 'summary-failed'; turn.summaryError = String((e && e.message) || e).slice(0, 200); turn.updatedAt = now(); await idbPut('turns', turn); }
      if (turn && turn.convId) { const c = await idbGet('conversations', turn.convId).catch(() => null); if (c) { c.summaryStatus = 'failed'; c.updatedAt = now(); await idbPut('conversations', c); } }
    } catch (_) {}
    return { ok: false, reason: 'summary-failed' };
  } finally { summarizingIds.delete(turnId); }
}

/* ---------------- 上下文构建 ---------------- */
async function buildContext(p) {
  const payload = p || {};
  await ensureIdentityReady();
  const st = await getSettings();
  const agentId = normalizeAgentId(payload.agentId);
  await rememberAgentName(agentId, payload.agentName);
  const ident = identityFromPayload(payload);
  if (st.observeOnly) return { ok: true, block: '', count: 0, scope: ident.scope, agentId, usedFallback: false, observeOnly: true, mode: st.injectMode };
  const q = String(payload.query || '').slice(0, 2000);
  if (!q) return { ok: true, block: '', count: 0, scope: ident.scope, agentId, usedFallback: false, mode: st.injectMode };
  let r = { rows: [], usedFallback: false };
  try { r = await retrieve(ident, agentId, q); } catch (_) { r = { rows: [], usedFallback: false }; }
  const block = r.rows.length ? formatMemoryBlock(r.rows, ident, agentId, r.usedFallback) : '';
  if (r.rows.length) void touchMemories(r.rows);
  dbg('ctx', { agentId, scope: ident.scope, n: r.rows.length, fb: !!r.usedFallback });
  return { ok: true, block, count: r.rows.length, scope: ident.scope, agentId, usedFallback: !!r.usedFallback, mode: st.injectMode };
}
/* ---------------- 角标/统计 ---------------- */
async function updateBadge() {
  try {
    const ident = currentIdentity();
    const prefix = (ident.scope === 'acct' ? 'acct:' + ident.accountId : 'machine:' + ident.machineId) + ':agent:';
    const all = await idbAll('memories');
    let n = 0;
    for (const r of all) { if (r.status === 'active' && String(r.ns || '').startsWith(prefix)) n++; }
    const txt = n > 999 ? '999+' : (n ? String(n) : '');
    await chrome.action.setBadgeBackgroundColor({ color: ident.scope === 'acct' ? '#2f6fed' : '#8a8f98' });
    await chrome.action.setBadgeText({ text: txt });
  } catch (_) {}
}
let badgeTimer = null;
function refreshBadge() { if (badgeTimer) return; badgeTimer = setTimeout(() => { badgeTimer = null; void updateBadge(); }, 400); }
async function computeStats(p) {
  await ensureIdentityReady();
  const ident = identityFromPayload(p || {});
  const mine = (r) => String(r.scope) === ident.scope && (ident.scope === 'acct' ? idMatches(r.accountId, ident.accountId) && !r.machineId : idMatches(r.machineId, ident.machineId) && !r.accountId);
  const mem = (await idbAll('memories')).filter(mine);
  const conv = (await idbAll('conversations')).filter(mine);
  const turns = (await idbAll('turns')).filter(mine);
  const byAgent = {};
  for (const m of mem) { const a = m.agentId || 'unknown'; if (!byAgent[a]) byAgent[a] = { agentId: a, name: agentName(a), active: 0, candidate: 0, summary: 0 }; if (m.status === 'active') { byAgent[a].active++; if (m.kind === 'summary') byAgent[a].summary++; } else if (m.status === 'candidate') byAgent[a].candidate++; }
  let quota = null;
  try { quota = await navigator.storage.estimate(); } catch (_) {}
  return {
    ok: true, identity: currentIdentity(), machineId: machineIdCache,
    memories: { total: mem.length, active: mem.filter((m) => m.status === 'active').length, candidate: mem.filter((m) => m.status === 'candidate').length, summary: mem.filter((m) => m.kind === 'summary' && m.status === 'active').length },
    conversations: conv.length, turns: turns.length,
    turnsByStatus: turns.reduce((o, t) => { o[t.status || 'unknown'] = (o[t.status || 'unknown'] || 0) + 1; return o; }, {}),
    byAgent: Object.values(byAgent).sort((a, b) => b.active - a.active),
    agents: agentNames.slice(), quota: quota ? { usage: quota.usage, quota: quota.quota } : null,
    settings: await getSettings()
  };
}

/* ---------------- 列表/导出/导入/清空 ---------------- */
function inScope(r, ident) {
  if (String(r.scope || '') !== String(ident.scope)) return false;
  return ident.scope === 'acct' ? (idMatches(r.accountId, ident.accountId) && !r.machineId) : (idMatches(r.machineId, ident.machineId) && !r.accountId);
}
async function listMemories(p) {
  await ensureIdentityReady();
  const q = p || {};
  const ident = identityFromPayload(q);
  const st = String(q.status || 'visible');
  let rows = (await idbAll('memories')).filter((r) => inScope(r, ident));
  if (q.agentId) rows = rows.filter((r) => normalizeAgentId(r.agentId) === normalizeAgentId(q.agentId));
  if (st === 'visible') rows = rows.filter((r) => r.status === 'active' || r.status === 'candidate');
  else if (st !== 'all') rows = rows.filter((r) => r.status === st);
  if (q.key) rows = rows.filter((r) => String(r.key) === String(q.key));
  if (q.kind) rows = rows.filter((r) => String(r.kind) === String(q.kind));
  const kw = clean(q.q || '', 60).toLowerCase();
  if (kw) rows = rows.filter((r) => (String(r.key) + ' ' + String(r.value)).toLowerCase().includes(kw));
  rows.sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
  return { ok: true, total: rows.length, rows: rows.slice(0, 800), identity: ident };
}
async function listConversations(p) {
  await ensureIdentityReady();
  const q = p || {};
  const ident = identityFromPayload(q);
  let rows = (await idbAll('conversations')).filter((r) => inScope(r, ident));
  if (q.agentId) rows = rows.filter((r) => normalizeAgentId(r.agentId) === normalizeAgentId(q.agentId));
  rows.sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
  return { ok: true, total: rows.length, rows: rows.slice(0, 300) };
}
async function listTurns(p) {
  await ensureIdentityReady();
  const q = p || {};
  const ident = identityFromPayload(q);
  let rows = (await idbAll('turns')).filter((r) => inScope(r, ident));
  if (q.agentId) rows = rows.filter((r) => normalizeAgentId(r.agentId) === normalizeAgentId(q.agentId));
  if (q.conversationId) rows = rows.filter((r) => String(r.conversationId) === String(q.conversationId));
  rows.sort((a, b) => Number(b.startedAt || 0) - Number(a.startedAt || 0));
  return { ok: true, total: rows.length, rows: rows.slice(0, 200) };
}
async function exportData(p) {
  await ensureIdentityReady();
  const ident = identityFromPayload(p || {});
  const mem = (await idbAll('memories')).filter((r) => inScope(r, ident));
  const conv = (await idbAll('conversations')).filter((r) => inScope(r, ident));
  const turns = (await idbAll('turns')).filter((r) => inScope(r, ident));
  return {
    ok: true,
    data: {
      app: 'ecq-local-memory', version: 2, exportedAt: now(),
      scope: ident.scope, accountId: ident.accountId || '', machineId: ident.scope === 'machine' ? (ident.machineId || '') : '',
      identityName: session.name || '', memories: mem, conversations: conv, turns,
      counts: { memories: mem.length, conversations: conv.length, turns: turns.length }
    }
  };
}
async function importData(p) {
  await ensureIdentityReady();
  const q = p || {};
  const data = q.data || q;
  if (!data || typeof data !== 'object') return { ok: false, reason: 'bad-data' };
  const ident = identityFromPayload(q);
  if (data.scope && String(data.scope) !== String(ident.scope)) return { ok: false, reason: 'scope-mismatch' };
  if (ident.scope === 'acct' && data.accountId && normalizeAccountId(data.accountId) !== ident.accountId) return { ok: false, reason: 'account-mismatch' };
  if (ident.scope === 'machine' && data.machineId && String(data.machineId) !== String(ident.machineId)) return { ok: false, reason: 'machine-mismatch' };
  const mem = Array.isArray(data.memories) ? data.memories : (Array.isArray(data) ? data : []);
  let imported = 0, skipped = 0;
  for (const m of mem) {
    if (!m || !m.key || !m.value) { skipped++; continue; }
    if (m.scope && String(m.scope) !== String(ident.scope)) { skipped++; continue; }
    if (ident.scope === 'acct' && m.accountId && normalizeAccountId(m.accountId) !== ident.accountId) { skipped++; continue; }
    if (ident.scope === 'machine' && m.machineId && String(m.machineId) !== String(ident.machineId)) { skipped++; continue; }
    const aid = normalizeAgentId(m.agentId || 'unknown');
    try {
      const rec = await upsertMemory({ ns: nsOf(ident, aid), scope: ident.scope, accountId: ident.accountId || '', machineId: ident.scope === 'machine' ? (ident.machineId || '') : '', agentId: aid, key: clean(m.key, 40), value: clean(m.value, 200), kind: normalizeKind(m.kind, m.key, m.value), source: 'imported', confidence: Number(m.confidence) || 0.7, importance: Number(m.importance) || 0.7, turnId: clean(m.turnId || '', 160), tags: Array.isArray(m.tags) ? m.tags : [] });
      if (!rec) { skipped++; continue; }
      rec.confirmCount = Math.max(Number(rec.confirmCount) || 1, Number(m.confirmCount) || 0);
      rec.useCount = Math.max(Number(rec.useCount) || 0, Number(m.useCount) || 0);
      rec.lastUsedAt = Math.max(Number(rec.lastUsedAt) || 0, Number(m.lastUsedAt) || 0);
      rec.lastConfirmedAt = Math.max(Number(rec.lastConfirmedAt) || 0, Number(m.lastConfirmedAt) || 0);
      if (m.lastUsedAt || m.lastConfirmedAt || m.confirmCount) await idbPut('memories', rec);
      if (m.status === 'archived' || m.status === 'candidate') {
        rec.status = m.status; rec.updatedAt = now(); await idbPut('memories', rec);
      }
      imported++;
    } catch (_) { skipped++; }
  }
  const convRows = Array.isArray(data.conversations) ? data.conversations : [];
  let importedConversations = 0, skippedConversations = 0;
  for (const c of convRows) {
    if (!c || typeof c !== 'object') { skippedConversations++; continue; }
    if (c.scope && String(c.scope) !== String(ident.scope)) { skippedConversations++; continue; }
    if (ident.scope === 'acct' && c.accountId && normalizeAccountId(c.accountId) !== ident.accountId) { skippedConversations++; continue; }
    if (ident.scope === 'machine' && c.machineId && String(c.machineId) !== String(ident.machineId)) { skippedConversations++; continue; }
    const aid = normalizeAgentId(c.agentId || 'unknown');
    const id = clean(c.id || '', 80);
    if (!id) { skippedConversations++; continue; }
    try {
      const old = await idbGet('conversations', id).catch(() => null);
      if (old && !inScope(old, ident)) { skippedConversations++; continue; }
      const rawConv = clean(c.conversationId || '', 120);
      const row = Object.assign({}, c, {
        id, conversationId: rawConv, agentId: aid, agentName: clean(c.agentName, 60) || agentName(aid),
        ns: nsOf(ident, aid), scope: ident.scope,
        accountId: ident.scope === 'acct' ? ident.accountId : '',
        machineId: ident.scope === 'machine' ? String(ident.machineId || '') : '',
        turnCount: Math.max(0, Number(c.turnCount) || 0),
        messageCount: Math.max(0, Number(c.messageCount) || 0),
        createdAt: Number(c.createdAt) || now(), updatedAt: Number(c.updatedAt) || now(),
        summaryStatus: ['pending', 'done', 'failed', 'running', 'disabled'].includes(String(c.summaryStatus)) ? String(c.summaryStatus) : 'pending'
      });
      await idbPut('conversations', row);
      importedConversations++;
    } catch (_) { skippedConversations++; }
  }
  const turnRows = Array.isArray(data.turns) ? data.turns : [];
  const TURN_STATUS = ['requested', 'completed', 'summarized', 'aborted', 'abandoned', 'cancelled', 'summary-failed', 'failed', 'disabled', 'summarizing'];
  let importedTurns = 0, skippedTurns = 0;
  for (const t of turnRows) {
    if (!t || typeof t !== 'object') { skippedTurns++; continue; }
    if (t.scope && String(t.scope) !== String(ident.scope)) { skippedTurns++; continue; }
    if (ident.scope === 'acct' && t.accountId && normalizeAccountId(t.accountId) !== ident.accountId) { skippedTurns++; continue; }
    if (ident.scope === 'machine' && t.machineId && String(t.machineId) !== String(ident.machineId)) { skippedTurns++; continue; }
    const aid = normalizeAgentId(t.agentId || 'unknown');
    const id = clean(t.id || '', 80);
    const userText = cut(String(t.userText || '').trim(), 12000);
    if (!id || !userText) { skippedTurns++; continue; }
    try {
      const old = await idbGet('turns', id).catch(() => null);
      if (old && !inScope(old, ident)) { skippedTurns++; continue; }
      const rawConv = clean(t.conversationId || '', 120);
      const convId = 'cv_' + hash32(convKeyOf(rawConv, aid, ident));
      const status = TURN_STATUS.includes(String(t.status)) ? String(t.status) : 'requested';
      const row = Object.assign({}, t, {
        id, conversationId: rawConv, convId, convKey: convKeyOf(rawConv, aid, ident),
        agentId: aid, agentName: clean(t.agentName, 60) || agentName(aid),
        ns: nsOf(ident, aid), scope: ident.scope,
        accountId: ident.scope === 'acct' ? ident.accountId : '',
        machineId: ident.scope === 'machine' ? String(ident.machineId || '') : '',
        userText, assistantText: cut(String(t.assistantText || ''), 20000),
        status, summarized: !!t.summarized,
        summary: clean(t.summary || '', 400), summaryError: clean(t.summaryError || '', 200),
        startedAt: Number(t.startedAt) || now(), createdAt: Number(t.createdAt) || now(),
        completedAt: Number(t.completedAt) || 0, summaryAt: Number(t.summaryAt) || 0,
        updatedAt: Number(t.updatedAt) || now()
      });
      await idbPut('turns', row);
      importedTurns++;
    } catch (_) { skippedTurns++; }
  }
  refreshBadge();
  return { ok: true, imported, skipped, importedConversations, skippedConversations, importedTurns, skippedTurns };
}
async function clearData(p) {
  const q = p || {};
  if (String(q.confirm || '') !== 'CLEAR') return { ok: false, reason: 'need-confirm' };
  await ensureIdentityReady();
  const ident = identityFromPayload(q);
  const aid = q.agentId ? normalizeAgentId(q.agentId) : '';
  let n = 0;
  for (const store of ['memories', 'conversations', 'turns']) {
    const rows = (await idbAll(store)).filter((r) => inScope(r, ident) && (!aid || normalizeAgentId(r.agentId) === aid));
    for (const r of rows) { try { await idbDelete(store, r.id); n++; } catch (_) {} }
  }
  refreshBadge();
  dbg('clear', { scope: ident.scope, agentId: aid, n });
  return { ok: true, cleared: n };
}
async function promoteMachine(p) {
  await ensureIdentityReady();
  if (!session.accountId) return { ok: false, reason: 'need-login' };
  const q = p || {};
  const acct = { accountId: session.accountId, machineId: machineIdCache, scope: 'acct' };
  const mach = { accountId: '', machineId: machineIdCache, scope: 'machine' };
  let agents = q.agentId ? [normalizeAgentId(q.agentId)] : uniq((await idbAll('memories')).filter((r) => String(r.scope) === 'machine' && idMatches(r.machineId, machineIdCache)).map((r) => normalizeAgentId(r.agentId)));
  let n = 0;
  for (const aid of agents) {
    const rows = (await rowsForNs(nsOf(mach, aid), false)).filter((r) => r.status === 'active');
    for (const r of rows) {
      try {
        await upsertMemory({ ns: nsOf(acct, aid), scope: 'acct', accountId: session.accountId, machineId: '', agentId: aid, key: r.key, value: r.value, kind: r.kind, source: 'promoted-machine', confidence: Math.min(0.95, Number(r.confidence) || 0.7) });
        n++;
      } catch (_) {}
    }
  }
  refreshBadge();
  return { ok: true, promoted: n, agents: agents.length };
}

/* ---------------- 清洗/初始化/消息 ---------------- */
async function consolidateSummaries() {
  const all = await idbAll('memories');
  const byNs = {};
  for (const r of all) { if (r.kind !== 'summary') continue; if (!byNs[r.ns]) byNs[r.ns] = []; byNs[r.ns].push(r); }
  let merged = 0;
  for (const ns of Object.keys(byNs)) {
    const act = byNs[ns].filter((r) => r.status === 'active').sort((a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0));
    const seen = new Map();
    for (const r of act) {
      const sig = String(r.key || '') + '\u0000' + String(r.value || '');
      const prev = seen.get(sig);
      if (!prev) { seen.set(sig, r); continue; }
      try {
        prev.confirmCount = Math.max(Number(prev.confirmCount || 0), Number(r.confirmCount || 0));
        prev.confidence = Math.max(Number(prev.confidence || 0), Number(r.confidence || 0));
        const turns = new Set([].concat(Array.isArray(prev.evidenceTurns) ? prev.evidenceTurns : [], Array.isArray(r.evidenceTurns) ? r.evidenceTurns : []));
        prev.evidenceTurns = Array.from(turns).slice(-80);
        prev.updatedAt = Math.max(Number(prev.updatedAt || 0), Number(r.updatedAt || 0));
        await idbPut('memories', prev);
        r.status = 'superseded';
        r.supersededBy = prev.id;
        r.supersededAt = now();
        r.updatedAt = now();
        await idbPut('memories', r);
        merged++;
      } catch (_) {}
    }
  }
  return { ok: true, archived: 0, merged };
}
async function cleanupStaleTurns() {
  const rows = await idbAll('turns');
  const ts = now(); let n = 0;
  for (const t of rows) {
    const age = ts - Number(t.startedAt || t.createdAt || 0);
    if (t.status === 'requested' && age > 10 * 60 * 1000) { t.status = 'abandoned'; t.updatedAt = ts; await idbPut('turns', t); n++; }
    else if (t.status === 'summarizing' && age > 15 * 60 * 1000) { t.status = 'summary-failed'; t.summaryError = 'stale'; t.updatedAt = ts; await idbPut('turns', t); n++; }
    else if (t.status === 'completed' && !t.summarized && age > 15 * 60 * 1000) { t.status = 'summary-failed'; t.summaryError = 'not-summarized'; t.updatedAt = ts; await idbPut('turns', t); n++; }
  }
  return { ok: true, cleaned: n };
}
async function livePageSnapshot() {
  const out = { ok: false, tabs: [], live: null, error: '' };
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: 'https://chat.echenqi.cn/*' }); }
  catch (e) { out.error = 'tabs-query: ' + String((e && e.message) || e); return out; }
  out.tabs = (tabs || []).map((t) => ({ id: t.id, active: !!t.active, lastAccessed: Number(t.lastAccessed) || 0, title: cut(t.title || '', 80), url: cut(t.url || '', 160) }));
  if (!tabs || !tabs.length) { out.error = 'no-chat-tab'; return out; }
  const ordered = [];
  const pushTab = (t) => { if (t && t.id != null && !ordered.some((x) => x.id === t.id)) ordered.push(t); };
  const chatOnly = (tabs || []).filter((t) => /\/c\//.test(String(t.url || '')));
  const fresh = (a, b) => (Number(b.lastAccessed) || 0) - (Number(a.lastAccessed) || 0) || (Number(b.id) || 0) - (Number(a.id) || 0);
  pushTab(tabs.find((t) => t.active && /\/c\//.test(String(t.url || ''))));
  chatOnly.slice().sort(fresh).forEach(pushTab);
  pushTab(tabs.find((t) => t.active));
  tabs.slice().sort(fresh).forEach(pushTab);
  const errors = [];
  const probes = [];
  let fallback = null;
  for (const tab of ordered) {
    try {
      const frames = await chrome.scripting.executeScript({
        target: { tabId: tab.id, allFrames: true },
        world: 'MAIN',
        func: () => {
          const r = { href: String(location.href || ''), isTop: false, pageV2: false, boot: null, pageAttr: '', contentAttr: '', debug: [], net: [] };
          try { r.isTop = window.top === window; } catch (_) {}
          try { r.pageV2 = !!window.__ECQ_MEM_PAGE_V2__; } catch (_) {}
          try { r.boot = window.__ECQ_MEM_BOOT__ || null; } catch (_) {}
          try { r.pageAttr = String(document.documentElement.dataset.ecqPage || ''); } catch (_) {}
          try { r.contentAttr = String(document.documentElement.dataset.ecqContent || ''); } catch (_) {}
          try { r.debug = (window.__ECQ_MEM_DEBUG__ || []).slice(-120); } catch (_) {}
          try { r.net = (window.__ECQ_MEM_NET__ || []).slice(-100); } catch (_) {}
          return r;
        }
      });
      const live = (frames || []).map((f) => Object.assign({ frameId: f.frameId }, f.result || {}));
      const pageV2 = live.some((f) => f && f.pageV2);
      const ready = live.some((f) => f && (f.pageAttr === '2-ready' || (f.boot && f.boot.stage === 'ready')));
      const snap = {
        ok: true,
        tabs: out.tabs,
        probes,
        live,
        tabId: tab.id,
        tabLastAccessed: Number(tab.lastAccessed) || 0,
        error: ''
      };
      probes.push({
        tabId: tab.id,
        lastAccessed: Number(tab.lastAccessed) || 0,
        pageV2,
        ready,
        bootAt: ((live.find((f) => f && f.boot) || {}).boot || {}).at || 0,
        href: ((live.find((f) => f && f.href) || {}).href || '')
      });
      if (pageV2 || ready) return snap;
      if (!fallback) fallback = snap;
    } catch (e) {
      errors.push('inject#' + tab.id + ': ' + String((e && e.message) || e));
    }
  }
  if (fallback) return fallback;
  out.error = errors.join(' | ') || 'inject-failed';
  return out;
}
async function doInit() {
  try { if (navigator.storage && navigator.storage.persist) await navigator.storage.persist(); } catch (_) {}
  await getMachineId();
  await loadSession();
  await loadDebugPersist();
  await loadAgentNames();
  try { await migrateV1(); } catch (_) {}
  try { await cleanupStaleTurns(); } catch (_) {}
  try { await consolidateSummaries(); } catch (_) {}
  await updateBadge();
  setupAlarms();
  dbg('init', { machineId: machineIdCache, account: session.accountId || '' });
  return { ok: true };
}
function init() { if (!initPromise) initPromise = doInit().catch((e) => ({ ok: false, reason: String((e && e.message) || e) })); return initPromise; }
async function handlePageMessage(type, payload) {
  const p = payload || {};
  switch (type) {
    case 'get-context': return buildContext(p);
    case 'chat-request': return storeChatRequest(p);
    case 'chat-complete': return storeChatComplete(p);
    case 'auth': { const r = await applyAuth(p); await updateBadge(); return r; }
    case 'logout': await clearSession(); await updateBadge(); return { ok: true, identity: currentIdentity() };
    case 'cancel-turn': {
      const t = p.turnId ? await idbGet('turns', p.turnId).catch(() => null) : await findTurnForComplete(p).catch(() => null);
      if (!t) return { ok: false, reason: 'turn-not-found' };
      if (t.status !== 'requested') return { ok: true, turnId: t.id, skipped: true, status: t.status };
      t.status = 'aborted'; t.abortedAt = now(); t.updatedAt = now(); await idbPut('turns', t);
      return { ok: true, turnId: t.id };
    }
    case 'request-auth': { broadcast({ type: 'request-auth' }); return { ok: true, identity: currentIdentity() }; }
    case 'page-debug': { const arr = Array.isArray(p.items) ? p.items.slice(-120) : []; pageDebug = debugDedupe(pageDebug.concat(arr)).slice(-300); persistDebugSoon(); return { ok: true, count: pageDebug.length }; }
    case 'debug': {
      await init();
      await ensureIdentityReady();
      if (!debugRing.length || !pageDebug.length) await loadDebugPersist();
      const live = await livePageSnapshot();
      return { ok: true, identity: currentIdentity(), machineId: machineIdCache, settings: await getSettings(), debug: debugRing.slice(-160), pageDebug: pageDebug.slice(-160), live };
    }
    case 'ping-page': { await ensureIdentityReady(); return { ok: true, identity: currentIdentity() }; }
    case 'get-state': { await ensureIdentityReady(); return { ok: true, identity: currentIdentity(), machineId: machineIdCache, settings: await getSettings() }; }
    default: return { ok: false, reason: 'unknown-type:' + type };
  }
}
async function handleUiMessage(type, payload) {
  const p = payload || {};
  switch (type) {
    case 'get-state': { await ensureIdentityReady(); return { ok: true, identity: currentIdentity(), machineId: machineIdCache, settings: await getSettings(), agentNames }; }
    case 'get-settings': return { ok: true, settings: await getSettings() };
    case 'set-settings': return { ok: true, settings: await setSettings(p) };
    case 'list-memories': return listMemories(p);
    case 'list-conversations': return listConversations(p);
    case 'list-turns': return listTurns(p);
    case 'export': return exportData(p);
    case 'import': return importData(p);
    case 'clear': return clearData(p);
    case 'promote-machine': return promoteMachine(p);
    case 'refresh-auth': { const r = await edgeRefreshAuth(); await updateBadge(); return r; }
    case 'stats': return computeStats(p);
    case 'open-memory': {
      try {
        await chrome.runtime.openOptionsPage();
        return { ok: true };
      } catch (e) {
        const tab = await chrome.tabs.create({ url: chrome.runtime.getURL('memory.html') });
        return { ok: true, tabId: tab && tab.id };
      }
    }
    case 'open-install': {
      const tab = await chrome.tabs.create({ url: chrome.runtime.getURL('install.html') });
      return { ok: true, tabId: tab && tab.id };
    }
    case 'debug': return handlePageMessage('debug', p);
    default: return { ok: false, reason: 'unknown-ui-type:' + type };
  }
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;
  if (msg.source === SOURCE_BG) return false;
  const type = String(msg.type || '');
  if (!type) return false;
  const run = msg.source === SOURCE_PAGE ? handlePageMessage(type, msg.payload) : handleUiMessage(type, msg.payload || msg);
  Promise.resolve(run).then((r) => { try { sendResponse(r); } catch (_) {} }).catch((e) => { try { sendResponse({ ok: false, reason: String((e && e.message) || e) }); } catch (_) {} });
  return true;
});
chrome.runtime.onInstalled.addListener(() => { void init(); setupAlarms(); });
chrome.runtime.onStartup.addListener(() => { void init(); });
function setupAlarms() {
  try {
    chrome.alarms.create('ecq-memory-hourly', { delayInMinutes: 5, periodInMinutes: 60 });
    chrome.alarms.create('ecq-memory-daily', { delayInMinutes: 10, periodInMinutes: 1440 });
  } catch (_) {}
}
try {
  chrome.alarms.onAlarm.addListener((a) => {
    if (!a || !a.name) return;
    if (a.name === 'ecq-memory-hourly') { void cleanupStaleTurns(); void refreshBadge(); }
    else if (a.name === 'ecq-memory-daily') { void consolidateSummaries(); void updateBadge(); }
  });
} catch (_) {}
void init();
/* ---------------- 后台登录态刷新（只读 cookie，不落盘 token） ---------------- */
async function edgeRefreshAuth() {
  const out = { ok: false };
  let token = '';
  try {
    const r = await fetch(ORIGIN + '/api/auth/refresh', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    if (r.status === 401) { await clearSession(); return { ok: true, loggedOut: true }; }
    if (r.ok) { const j = await r.json().catch(() => null); token = (j && (j.token || j.accessToken || (j.data && (j.data.token || j.data.accessToken)))) || ''; }
  } catch (_) {}
  try {
    const h = token ? { Authorization: 'Bearer ' + token } : {};
    const ur = await fetch(ORIGIN + '/api/user', { credentials: 'include', headers: h });
    if (ur.status === 401) { await clearSession(); return { ok: true, loggedOut: true }; }
    const uj = await ur.json().catch(() => null);
    const user = uj && (uj.user || (uj.data && uj.data.user) || uj.data || uj);
    if (!user || typeof user !== 'object') { return { ok: false, reason: 'no-user' }; }
    const ident = await updateSessionFromUser(user);
    return { ok: true, identity: ident, loggedOut: !ident.loggedIn };
  } catch (e) { return { ok: false, reason: String((e && e.message) || e) }; }
}
