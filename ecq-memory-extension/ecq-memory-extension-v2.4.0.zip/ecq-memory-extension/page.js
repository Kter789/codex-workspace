/* ECQ Local Memory - MAIN world bridge (v2)
 * 只旁路监听页面自身的聊天请求/响应，记忆保存在扩展 IndexedDB，不修改平台服务端。
 * 记忆注入只改发给服务器的请求副本，原始 userText 永远保持干净。
 */
(() => {
  'use strict';
  if (window.__ECQ_MEM_PAGE_V2__) return;
  window.__ECQ_MEM_PAGE_V2__ = true;
  window.__ECQ_MEM_BOOT__ = { stage: 'start', err: '', at: Date.now(), ver: '2.1.0' };
  try { document.documentElement.dataset.ecqPage = '2'; } catch (_) {}

  const SOURCE_PAGE = 'ecq-mem-page';
  const SOURCE_BG = 'ecq-mem-bg';
  const CTX_TIMEOUT_MS = 2000;
  const CTX_TTL_MS = 12000;
  const DEBUG_MAX = 120;
  const NET_MAX = 80;
  const AGENT_FALLBACK = 'unknown';

  const state = {
    identity: null,
    settings: null,
    auth: null,
    ready: false
  };
  const debugRing = [];
  const netRing = [];
  const debugQueue = [];
  const statusSig = new Map();
  let debugTimer = 0;
  const ctxCache = new Map();
  const ctxInflight = new Map();
  const pending = new Map();
  const turns = new Map();
  const convTurns = new Map();
  const sentLength = new Map();
  const abortedTurns = new Set();
  let lastTurnId = '';

  try {
    window.__ECQ_MEM_NET__ = netRing;
    window.__ECQ_MEM_DEBUG__ = debugRing;
  } catch (_) {}

  const origFetch = window.fetch ? window.fetch.bind(window) : null;
  const origXhrOpen = window.XMLHttpRequest && window.XMLHttpRequest.prototype.open;
  const origXhrSend = window.XMLHttpRequest && window.XMLHttpRequest.prototype.send;
  const OrigES = window.EventSource;

  const now = () => Date.now();
  const delay = (ms) => new Promise((r) => setTimeout(r, ms));
  const rid = () => 'r_' + now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  const turnIdNew = () => 't_' + now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  const cut = (s, n) => (typeof s === 'string' ? s.slice(0, n) : '');
  const safeJson = (s) => { try { return JSON.parse(s); } catch (_) { return null; } };
  const absUrl = (u) => { try { return new URL(u, location.origin).href; } catch (_) { return String(u || ''); } };
  const hash32 = (s) => {
    let h = 2166136261;
    const t = String(s || '');
    for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(36);
  };

  function debug(kind, data) {
    const item = { ts: now(), kind, data: data || null };
    debugRing.push(item);
    if (debugRing.length > DEBUG_MAX) debugRing.shift();
    debugQueue.push(item);
    if (debugTimer) return;
    debugTimer = setTimeout(() => {
      debugTimer = 0;
      const items = debugQueue.splice(0, 80);
      if (items.length) post('page-debug', { items });
    }, 400);
  }

  function post(type, payload, extra) {
    try {
      window.postMessage(Object.assign({ source: SOURCE_PAGE, type, payload: payload || {} }, extra || {}), '*');
    } catch (_) {}
  }

  function safeKeys(obj, max) {
    if (!obj || typeof obj !== 'object') return [];
    try { return Object.keys(obj).slice(0, max || 16); } catch (_) { return []; }
  }

  function textFromContent(value, depth) {
    if (value == null || depth > 3) return '';
    if (typeof value === 'string') return value.trim();
    if (Array.isArray(value)) {
      return value.map((item) => textFromContent(item, (depth || 0) + 1)).filter(Boolean).join(' ').trim();
    }
    if (typeof value === 'object') {
      for (const key of ['text', 'content', 'value', 'parts', 'message']) {
        const text = textFromContent(value[key], (depth || 0) + 1);
        if (text) return text;
      }
    }
    return '';
  }

  function redactedJson(value) {
    try {
      const obj = typeof value === 'string' ? safeJson(value) : value;
      if (obj == null) return cut(String(value || ''), 500);
      return JSON.stringify(obj, (key, val) => (/token|cookie|authorization|password|secret|session/i.test(String(key || '')) ? '[redacted]' : val));
    } catch (_) {
      return cut(String(value || ''), 500);
    }
  }

  function probePostBody(url, method, body, source) {
    try {
      if (method !== 'POST' || !/\/api\//.test(String(url || ''))) return;
      const likely = isChatPost(url, method) || /(chat|agent|message|conversation|completion)/i.test(String(url || ''));
      let bodyText = '';
      let parsed = null;
      if (typeof body === 'string') bodyText = body;
      else if (body && typeof body === 'object') {
        if (typeof FormData !== 'undefined' && body instanceof FormData) bodyText = '[FormData]';
        else if (typeof URLSearchParams !== 'undefined' && body instanceof URLSearchParams) bodyText = body.toString();
        else bodyText = redactedJson(body);
      }
      if (bodyText && bodyText.charAt(0) === '{') parsed = safeJson(bodyText);
      const data = {
        src: source || 'fetch',
        url: cut(String(url || ''), 160),
        isChat: isChatPost(url, method),
        bodyType: body == null ? 'none' : (typeof body === 'string' ? 'string' : (body.constructor && body.constructor.name) || typeof body),
        bodyLen: bodyText.length
      };
      if (parsed && typeof parsed === 'object') {
        data.keys = safeKeys(parsed, 24);
        data.userText = textFromContent(extractUserText(parsed)).slice(0, 160);
      }
      if (likely) data.preview = cut(redactedJson(parsed || bodyText), 500);
      debug('post-probe', data);
    } catch (e) {
      debug('post-probe-error', { error: String((e && e.message) || e) });
    }
  }

  async function probeFetchPost(input, init, url, method) {
    if (method !== 'POST' || !/\/api\//.test(String(url || ''))) return;
    let body = init && init.body;
    if (body == null && input && typeof input === 'object' && typeof input.clone === 'function') {
      try { body = await input.clone().text(); } catch (_) {}
    }
    probePostBody(url, method, body, 'fetch');
  }

  function statusAggLength(res) {
    try {
      const b = (res && res.data && typeof res.data === 'object') ? res.data : (res || {});
      const rs = b.resumeState || b.resume_state || {};
      const agg = rs.aggregatedContent || rs.aggregated_content;
      if (!Array.isArray(agg)) return 0;
      return agg.map((x) => (typeof x === 'string' ? x : String((x && (x.text || x.content)) || ''))).join('').length;
    } catch (_) { return 0; }
  }

  function noteNet(phase, method, url, status, req, res, important) {
    try {
      const u = String(url || '');
      if (!/\/api\//.test(u)) return;
      const item = {
        ts: now(),
        phase,
        method: String(method || 'GET'),
        path: u.replace(location.origin, '').split('?')[0],
        status: Number(status) || 0,
        reqKeys: safeKeys(req, 16),
        resKeys: safeKeys(res, 16)
      };
      if (req && typeof req === 'object') {
        item.req = {
          agentId: cut(String(req.agent_id || req.agentId || ''), 80),
          textLen: String(req.text || '').length,
          conv: cut(String(req.conversationId || ''), 80)
        };
      }
      if (res && typeof res === 'object') {
        const b = (res.data && typeof res.data === 'object') ? res.data : res;
        item.res = {
          status: cut(String(b.status || b.state || ''), 24),
          active: b.active === true ? true : (b.active === false ? false : null),
          conv: cut(String(extractConversationIdFromResponse(res) || ''), 80),
          aggLen: statusAggLength(res),
          replyLen: assistantFromObject(res).length
        };
      }
      netRing.push(item);
      if (netRing.length > NET_MAX) netRing.shift();
      const sig = item.res ? [item.res.status, item.res.active, item.res.aggLen, item.res.conv].join('|') : '';
      const prev = statusSig.get(item.path) || '';
      const changed = !!sig && sig !== prev;
      if (changed) statusSig.set(item.path, sig);
      if (important || changed || (item.res && /error|fail/i.test(String(item.res.status || '')))) {
        debug('net', item);
      }
    } catch (_) {}
  }

  function rpc(type, payload, timeout) {
    return new Promise((resolve) => {
      const reqId = rid();
      const timer = setTimeout(() => {
        if (pending.has(reqId)) { pending.delete(reqId); resolve(null); }
      }, Math.max(300, timeout || 1500));
      pending.set(reqId, { resolve, timer, type });
      post(type, payload, { reqId });
    });
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window) return;
    const msg = ev.data;
    if (!msg || msg.source !== SOURCE_BG) return;

    if (msg.type === 'reply' && msg.reqId && pending.has(msg.reqId)) {
      const p = pending.get(msg.reqId);
      pending.delete(msg.reqId);
      clearTimeout(p.timer);
      p.resolve(msg.payload || null);
      return;
    }
    if (msg.type === 'session-updated') {
      const before = state.identity ? String(state.identity.accountId || '') : '';
      state.identity = msg.payload || null;
      const after = state.identity ? String(state.identity.accountId || '') : '';
      if (before !== after) clearContextCache();
      debug('session-updated', { accountId: after });
      return;
    }
    if (msg.type === 'settings-changed') {
      state.settings = msg.payload || state.settings;
      debug('settings-changed', { mode: state.settings && state.settings.injectMode });
      return;
    }
    if (msg.type === 'request-auth') {
      void refreshAuth('bridge');
    }
  });

  function accountIdNow() {
    if (state.auth && state.auth.accountId) return String(state.auth.accountId);
    if (state.identity && state.identity.accountId) return String(state.identity.accountId);
    return '';
  }

  function loggedOutNow() {
    if (accountIdNow()) return false;
    if (state.identity && state.identity.loggedIn === false) return true;
    if (state.identity && state.identity.loggedIn === true && !state.identity.accountId) return false;
    return false;
  }

  function identityPayload(extra) {
    const out = Object.assign({ accountKnown: true }, extra || {});
    const aid = accountIdNow();
    if (aid) out.accountId = aid;
    else if (loggedOutNow()) out.loggedOut = true;
    return out;
  }

  function clearContextCache() {
    ctxCache.clear();
    ctxInflight.clear();
    debug('ctx-cache-cleared', {});
  }

  function ctxKey(agentId, userText) {
    const aid = accountIdNow() || (state.identity && state.identity.machineId) || 'anon';
    return [aid, state.auth ? 'a' : 's', String(agentId || AGENT_FALLBACK), hash32(userText)].join('|');
  }

  function getCachedContext(agentId, userText) {
    const hit = ctxCache.get(ctxKey(agentId, userText));
    if (hit && now() - hit.at < CTX_TTL_MS) return hit.value;
    return null;
  }

  function requestContext(agentId, agentName, userText) {
    const st = state.settings || {};
    if (st.observeOnly === true) return Promise.resolve({ block: '', count: 0, observeOnly: true });
    if (!userText || String(userText).trim().length < (Number(st.minUserChars) || 6)) {
      return Promise.resolve({ block: '', count: 0, skipped: 'short' });
    }
    const cached = getCachedContext(agentId, userText);
    if (cached) return Promise.resolve(cached);

    const key = ctxKey(agentId, userText);
    let inflight = ctxInflight.get(key);
    if (!inflight) {
      inflight = rpc('get-context', identityPayload({
        agentId: agentId || AGENT_FALLBACK,
        agentName: agentName || '',
        query: userText,
        userText,
        url: location.href
      }), CTX_TIMEOUT_MS + 600).then((val) => {
        if (val && (val.block || val.observeOnly || val.count === 0)) {
          ctxCache.set(key, { at: now(), value: val });
        }
        ctxInflight.delete(key);
        return val;
      }).catch(() => {
        ctxInflight.delete(key);
        return null;
      });
      ctxInflight.set(key, inflight);
    }
    return Promise.race([inflight, delay(CTX_TIMEOUT_MS).then(() => null)]);
  }

  function isChatPost(url, method) {
    if (method !== 'POST') return false;
    let p = '';
    try { p = new URL(url, location.origin).pathname; }
    catch (_) { p = String(url || '').split(/[?#]/)[0]; }
    if (!/^\/api\/agents\/chat(?:\/|$)/.test(p)) return false;
    if (/\/(?:abort|stop|cancel|status|stream|active|history)(?:\/|$)/.test(p)) return false;
    return true;
  }
  function isStreamGet(url, method) {
    return method === 'GET' && /\/api\/agents\/chat\/stream\//.test(url);
  }
  function isAbort(url, method) {
    return method === 'POST' && /\/api\/agents\/chat\/abort/.test(url);
  }
  function isStatus(url, method) {
    return method === 'GET' && /\/api\/agents\/chat\/status\//.test(url);
  }

  function extractAgentId(body, url) {
    if (body && typeof body === 'object') {
      const c = body.conversation || {};
      const eo = body.endpointOption || {};
      const direct = body.agent_id || body.agentId || c.agent_id || c.agentId || eo.agent_id || eo.agentId;
      if (direct) return String(direct);
      if (c.endpoint === 'agents' && c.model) return String(c.model);
      if (eo.endpoint === 'agents' && eo.model) return String(eo.model);
      if (body.endpoint === 'agents' && body.model) return String(body.model);
    }
    const m2 = String(url || '').match(/\/api\/agents\/chat\/(agent_[^/?#]+)/);
    if (m2) return decodeURIComponent(m2[1]);
    const m = String(url || '').match(/\/d\/([^/?#]+)/);
    if (m) return decodeURIComponent(m[1]);
    const m3 = String(location.href || '').match(/\/d\/([^/?#]+)/);
    return m3 ? decodeURIComponent(m3[1]) : '';
  }

  function extractAgentName(body) {
    if (!body || typeof body !== 'object') return '';
    return String(body.agent_name || body.agentName || body.name || '');
  }

  function extractConversationId(body, url) {
    if (body && typeof body === 'object') {
      const c = body.conversation || {};
      const id = c.conversationId || body.conversationId || (body.userMessage && body.userMessage.conversationId);
      if (id) return String(id);
    }
    const m = String(url || '').match(/\/c\/([^/?#]+)/);
    return m ? decodeURIComponent(m[1]) : '';
  }

  function extractUserText(body) {
    if (!body || typeof body !== 'object') return '';
    const direct = textFromContent(body.text);
    if (direct) return direct;
    if (body.userMessage) {
      const userMessage = textFromContent(body.userMessage);
      if (userMessage) return userMessage;
    }
    for (const key of ['content', 'prompt', 'query', 'input', 'message']) {
      const text = textFromContent(body[key]);
      if (text) return text;
    }
    if (Array.isArray(body.messages)) {
      for (let i = body.messages.length - 1; i >= 0; i--) {
        const m = body.messages[i];
        if (!m) continue;
        const user = m.isCreatedByUser || m.sender === 'User' || m.sender === 'user' || m.role === 'user';
        if (!user) continue;
        const text = textFromContent(m.text) || textFromContent(m.content) || textFromContent(m.message) || textFromContent(m);
        if (text) return text;
      }
    }
    return '';
  }

  function extractConversationIdFromResponse(obj) {
    if (!obj || typeof obj !== 'object') return '';
    const direct = obj.conversationId || obj.conversation_id || obj.convId ||
      (obj.conversation && (obj.conversation.conversationId || obj.conversation.id || obj.conversation._id)) ||
      (obj.data && (obj.data.conversationId || obj.data.conversation_id || obj.data.convId ||
        (obj.data.conversation && (obj.data.conversation.conversationId || obj.data.conversation.id || obj.data.conversation._id)))) ||
      (obj.result && (obj.result.conversationId || obj.result.conversation_id)) ||
      (obj.message && (obj.message.conversationId || obj.message.conversation_id));
    return direct ? String(direct) : '';
  }

  function assistantFromObject(obj) {
    if (!obj) return '';
    const roots = [obj, obj.data, obj.result, obj.payload].filter((x) => x && typeof x === 'object');
    for (const root of roots) {
      const cand = root.assistantMessage || root.assistant_message || root.reply || root.answer || root.output;
      if (typeof cand === 'string' && cand.trim()) return cand.trim();
      if (cand && typeof cand === 'object') {
        const t = cand.content || cand.text;
        if (typeof t === 'string' && t.trim()) return t.trim();
      }
      if (root.message && typeof root.message === 'object') {
        const role = String(root.message.role || root.message.sender || '');
        if (!role || /assistant|ai|bot/i.test(role)) {
          const t = root.message.content || root.message.text;
          if (typeof t === 'string' && t.trim()) return t.trim();
        }
      }
      if (Array.isArray(root.choices) && root.choices[0] && root.choices[0].message) {
        const t = root.choices[0].message.content;
        if (typeof t === 'string' && t.trim()) return t.trim();
      }
      const _top = root.text || root.content;
      if (typeof _top === 'string' && _top.trim()) {
        const _sender = String(root.sender || root.role || '');
        const _fromUser = root.isCreatedByUser === true || /^(user|human|me)$/i.test(_sender);
        if (!_fromUser) return _top.trim();
      }
      if (Array.isArray(root.messages)) {
        for (let i = root.messages.length - 1; i >= 0; i--) {
          const m = root.messages[i] || {};
          const role = String(m.role || m.sender || '');
          if (role && !/assistant|ai|bot/i.test(role)) continue;
          const t = m.content || m.text;
          if (typeof t === 'string' && t.trim()) return t.trim();
        }
      }
    }
    return '';
  }

  function statusReplyText(b, outer) {
    if (!b || typeof b !== 'object') return '';
    const rs = b.resumeState || b.resume_state || {};
    const agg = rs.aggregatedContent || rs.aggregated_content || rs.content;
    if (Array.isArray(agg)) {
      const t = agg.map((x) => (typeof x === 'string' ? x : String((x && (x.text || x.content || x.value)) || ''))).join('');
      if (t.trim()) return t.trim();
    }
    if (typeof agg === 'string' && agg.trim()) return agg.trim();
    const lists = [rs.messages, rs.items, b.messages, b.items];
    for (const list of lists) {
      if (!Array.isArray(list)) continue;
      for (let i = list.length - 1; i >= 0; i--) {
        const m = list[i] || {};
        const role = String(m.role || m.sender || m.type || '');
        if (role && !/assistant|ai|bot|model|agent/i.test(role)) continue;
        const t = m.text || m.content;
        if (typeof t === 'string' && t.trim()) return t.trim();
      }
    }
    return assistantFromObject(b) || assistantFromObject(outer);
  }

  function captureStatusPayload(obj, conv, source) {
    if (!obj || typeof obj !== 'object') return '';
    const roots = [obj, obj.data, obj.result, obj.payload].filter((x) => x && typeof x === 'object');
    let b = null;
    for (const r of roots) {
      if (r.status != null || r.state != null || r.active != null || r.resumeState || r.resume_state) { b = r; break; }
    }
    if (!b) return '';
    const st = String(b.status || b.state || '').toLowerCase();
    if (/error|fail|cancel|abort|reject/.test(st)) return '';
    const text = statusReplyText(b, obj);
    if (!text) return '';
    const done = /^(complete|completed|done|finished|success|succeeded|end|ended)$/.test(st) ||
      (b.active === false && !/running|pending|starting|processing|queued|streaming|thinking/.test(st));
    if (!done) return '';
    const c = conv || extractConversationIdFromResponse(obj) || '';
    const tid = (c && convTurns.get(c)) || lastTurnId || '';
    if (!tid) {
      debug('status-no-turn', { conv: cut(c, 120), len: text.length, source: source || 'status-poll' });
      return '';
    }
    if (c) convTurns.set(c, tid);
    completeTurn(tid, c, text, source || 'status-poll');
    return text;
  }

  async function captureStatusResponse(res, url, source) {
    try {
      const j = await res.clone().json();
      const m = String(url || '').match(/\/api\/agents\/chat\/status\/([^/?#]+)/);
      const conv = m ? decodeURIComponent(m[1]) : '';
      noteNet(source || 'status', 'GET', url, res.status, null, j, true);
      captureStatusPayload(j, conv, source || 'status');
    } catch (_) {}
  }

  function parseSseText(text) {
    let full = '';
    for (const raw of String(text || '').split(/\r?\n/)) {
      const l = raw.trim();
      if (!l || l.startsWith(':')) continue;
      let data = '';
      if (l.startsWith('data:')) data = l.slice(5).trim();
      else if (l.startsWith('{')) data = l;
      else continue;
      if (!data || data === '[DONE]') continue;
      const obj = safeJson(data);
      const chunk = obj ? eventText(obj) : (data.startsWith('{') ? '' : data);
      if (chunk) full = mergeText(full, chunk);
    }
    return full.trim();
  }

  async function capturePostSse(res, info) {
    if (!res || !res.body) return;
    let reader;
    try { reader = res.clone().body.getReader(); } catch (_) { return; }
    const dec = new TextDecoder('utf-8');
    let buf = '';
    let full = '';
    let done = false;
    const acc = (raw) => {
      const l = raw.replace(/\r$/, '').trim();
      if (!l || l.startsWith(':')) return;
      let data = '';
      if (l.startsWith('data:')) data = l.slice(5).trim();
      else if (l.startsWith('{')) data = l;
      else return;
      if (!data) return;
      if (data === '[DONE]') { done = true; return; }
      const obj = safeJson(data);
      const chunk = obj ? eventText(obj) : (data.startsWith('{') ? '' : data);
      if (chunk) full = mergeText(full, chunk);
    };
    try {
      while (!done) {
        const r = await reader.read();
        if (r.done) break;
        buf += dec.decode(r.value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const l = buf.slice(0, i);
          buf = buf.slice(i + 1);
          acc(l);
        }
      }
      buf += dec.decode();
      if (buf) acc(buf);
    } catch (e) {
      debug('post-sse-error', { error: String(e && e.message || e) });
    } finally {
      try { reader.releaseLock(); } catch (_) {}
    }
    if (full.trim()) completeTurn(info.turnId, info.conversationId, full, 'post-sse');
  }

  function eventText(obj) {
    if (!obj || typeof obj !== 'object') return '';
    const parts = [];
    const seen = new Set();
    const skip = /^(id|_id|conversationId|conversation_id|messageId|createdAt|updatedAt|type|role|sender|model|finish_reason|index|status|error|usage)$/i;
    function walk(x, depth, path) {
      if (!x || depth > 7) return;
      if (typeof x === 'string') {
        const s = x.trim();
        if (s && /(text|content|delta|value|answer|response|message|output|completion|token)$/i.test(path) && !seen.has(s)) {
          seen.add(s);
          parts.push(s);
        }
        return;
      }
      if (Array.isArray(x)) { for (const it of x) walk(it, depth + 1, path); return; }
      if (typeof x === 'object') {
        for (const k of Object.keys(x)) {
          if (skip.test(k)) continue;
          if (typeof x[k] === 'string' || typeof x[k] === 'object') walk(x[k], depth + 1, k);
        }
      }
    }
    walk(obj, 0, '');
    const uniq = [];
    for (const p of parts) {
      if (uniq.some((q) => q === p || q.includes(p))) continue;
      for (let i = uniq.length - 1; i >= 0; i--) if (p.includes(uniq[i])) uniq.splice(i, 1);
      uniq.push(p);
    }
    return uniq.join('');
  }

  function mergeText(full, chunk) {
    if (!chunk) return full;
    if (!full) return chunk;
    if (chunk === full) return full;
    if (chunk.startsWith(full)) return chunk;
    if (full.endsWith(chunk)) return full;
    if (full.includes(chunk) && chunk.length < full.length * 0.8) return full;
    return full + chunk;
  }

  function injectionMode() {
    const m = String((state.settings && state.settings.injectMode) || 'prefix').toLowerCase();
    return ['prefix', 'context', 'system', 'promptprefix', 'off'].includes(m) ? m : 'prefix';
  }

  function withMemoryBlock(body, block) {
    if (!body || typeof body !== 'object' || !block) return body;
    const mode = injectionMode();
    if (mode === 'off') return body;
    const original = extractUserText(body);
    if (original.startsWith('[本地记忆')) return body;
    const prefix = block + '\n\n';
    if (mode === 'system') {
      if (typeof body.system === 'string') body.system = body.system ? body.system + '\n\n' + block : block;
      else if (typeof body.text === 'string') body.text = prefix + body.text;
      return body;
    }
    if (mode === 'context') {
      if (typeof body.context === 'string') body.context = body.context ? body.context + '\n\n' + block : block;
      else if (typeof body.text === 'string') body.text = prefix + body.text;
      return body;
    }
    if (mode === 'promptprefix') {
      if (typeof body.promptPrefix === 'string') body.promptPrefix = body.promptPrefix ? body.promptPrefix + '\n\n' + block : block;
      else if (typeof body.text === 'string') body.text = prefix + body.text;
      return body;
    }
    if (typeof body.text === 'string') body.text = prefix + body.text;
    return body;
  }

  function makeTurn(info) {
    turns.set(info.turnId, info);
    lastTurnId = info.turnId;
    if (info.conversationId) convTurns.set(String(info.conversationId), info.turnId);
    return info;
  }

  function reportRequest(info, attempt) {
    const n = Number(attempt) || 0;
    const payload = identityPayload({
      turnId: info.turnId,
      agentId: info.agentId || AGENT_FALLBACK,
      agentName: info.agentName || '',
      conversationId: info.conversationId || '',
      userText: info.userText,
      startedAt: info.startedAt,
      url: info.url
    });
    rpc('chat-request', payload, 1800).then((r) => {
      if (r && r.ok === false && r.reason === 'turn-identity-mismatch' && n < 1) {
        void refreshAuth('turn-mismatch').then(() => reportRequest(info, n + 1));
      }
    });
  }

  function abortTurn(info) {
    if (!info || info.aborted) return;
    info.aborted = true;
    abortedTurns.add(info.turnId);
    post('cancel-turn', identityPayload({
      turnId: info.turnId,
      agentId: info.agentId,
      conversationId: info.conversationId
    }));
    debug('turn-abort', { turnId: info.turnId });
  }

  function bindAbort(info, init, input) {
    try {
      const sig = (init && init.signal) || (input && input.signal);
      if (sig && typeof sig.addEventListener === 'function') {
        if (sig.aborted) abortTurn(info);
        else sig.addEventListener('abort', () => abortTurn(info), { once: true });
      }
    } catch (_) {}
  }

  function completeTurn(turnId, conversationId, text, source) {
    const tid = turnId || lastTurnId;
    if (!tid || abortedTurns.has(tid)) return;
    const reply = String(text || '').trim();
    if (reply.length < 1) return;
    const prev = sentLength.get(tid) || 0;
    if (reply.length <= prev) return;
    const info = turns.get(tid) || {};
    sentLength.set(tid, reply.length);
    const payload = identityPayload({
      turnId: tid,
      agentId: info.agentId || AGENT_FALLBACK,
      agentName: info.agentName || '',
      conversationId: conversationId || info.conversationId || '',
      userText: info.userText || '',
      assistantText: reply,
      startedAt: info.startedAt || now(),
      endedAt: now(),
      source: source || 'stream',
      url: info.url || location.href
    });
    const send = (attempt) => {
      rpc('chat-complete', payload, 2500).then((r) => {
        if (r && r.ok === false && r.reason === 'turn-not-found') {
          if (attempt < 2 && !abortedTurns.has(tid)) {
            try { reportRequest(info); } catch (_) {}
            setTimeout(() => send(attempt + 1), attempt === 0 ? 400 : 1200);
            return;
          }
          sentLength.delete(tid);
          debug('complete-turn-not-found', { turnId: tid, attempt });
        }
      }).catch(() => {});
    };
    send(0);
    debug('turn-complete', { turnId: tid, chars: reply.length, source });
  }

  async function prepareChat(body, init, input, url) {
    const agentId = extractAgentId(body, url) || AGENT_FALLBACK;
    const agentName = extractAgentName(body);
    const userText = extractUserText(body);
    const conversationId = extractConversationId(body, url);
    const info = makeTurn({
      turnId: turnIdNew(),
      agentId,
      agentName,
      userText,
      conversationId,
      startedAt: now(),
      url,
      aborted: false,
      ctxBlock: ''
    });
    bindAbort(info, init, input);
    if (!userText) {
      debug('user-text-empty', {
        src: 'fetch',
        url: cut(url, 160),
        keys: safeKeys(body, 24),
        preview: cut(redactedJson(body), 500)
      });
      return info;
    }

    reportRequest(info);
    const ctx = await requestContext(agentId, agentName, userText);
    if (ctx && ctx.block) info.ctxBlock = String(ctx.block);
    if (info.aborted) info.ctxBlock = '';
    return info;
  }

  function buildInitWithBody(init, bodyText) {
    const next = Object.assign({}, init || {});
    next.body = bodyText;
    try {
      const h = new Headers((init && init.headers) || {});
      h.delete('content-length');
      h.set('content-type', 'application/json');
      next.headers = h;
    } catch (_) {}
    return next;
  }

  async function fetchChat(input, init, url, method) {
    let bodyText = '';
    if (init && typeof init.body === 'string') bodyText = init.body;
    else if (input && typeof input === 'object' && input.clone) {
      try { bodyText = await input.clone().text(); } catch (_) {}
    }
    const body = safeJson(bodyText);
    if (!body || typeof body !== 'object') return origFetch(input, init);

    const info = await prepareChat(body, init, input, url);
    let outgoing = input;
    let outgoingInit = init;
    if (info.ctxBlock && !info.aborted) {
      const copy = safeJson(bodyText);
      withMemoryBlock(copy, info.ctxBlock);
      const newBody = JSON.stringify(copy);
      if (typeof input === 'string') {
        outgoingInit = buildInitWithBody(init, newBody);
      } else if (input && typeof input === 'object' && input.url) {
        outgoing = new Request(input, { body: newBody });
        if (init) outgoingInit = buildInitWithBody(init, newBody);
        else outgoingInit = undefined;
      } else {
        outgoingInit = buildInitWithBody(init, newBody);
      }
    }

    let res;
    try {
      res = await origFetch(outgoing, outgoingInit);
    } catch (e) {
      abortTurn(info);
      throw e;
    }
    if (res && (res.status === 401 || res.status === 403)) void onAuthInvalid();
    void handleChatPostResponse(res, info);
    return res;
  }

  async function handleChatPostResponse(res, info) {
    if (!res) return;
    try {
      const ct = String(res.headers.get('content-type') || '').toLowerCase();
      if (ct.includes('application/json')) {
        const j = await res.clone().json().catch(() => null);
        if (!j) return;
        noteNet('chat-post', 'POST', info.url, res.status, null, j, true);
        const conv = extractConversationIdFromResponse(j);
        if (conv && conv !== info.conversationId) {
          info.conversationId = conv;
          convTurns.set(conv, info.turnId);
          reportRequest(info);
        }
        const txt = assistantFromObject(j);
        if (txt) completeTurn(info.turnId, conv || info.conversationId, txt, 'post-json');
      } else if (ct.includes('event-stream') || ct.includes('ndjson') || ct.includes('text/plain') || ct.includes('octet-stream')) {
        noteNet('chat-post-stream', 'POST', info.url, res.status, null, null, true);
        await capturePostSse(res, info);
      } else if (res.body) {
        noteNet('chat-post-stream', 'POST', info.url, res.status, null, null, true);
        await capturePostSse(res, info);
      }
    } catch (_) {}
  }

  async function captureSse(res, url) {
    const conv = (String(url).match(/\/stream\/([^/?#]+)/) || [])[1] || '';
    const turnId = (conv && convTurns.get(conv)) || lastTurnId || '';
    const info = turns.get(turnId) || {};
    if (!res || !res.body) return;
    let reader;
    try { reader = res.clone().body.getReader(); } catch (_) { return; }
    const dec = new TextDecoder('utf-8');
    let buf = '';
    let full = '';
    let dataLines = [];
    let done = false;

    const dispatch = () => {
      if (!dataLines.length) return;
      const data = dataLines.join('\n').trim();
      dataLines = [];
      if (!data) return;
      if (data === '[DONE]') { done = true; return; }
      const obj = safeJson(data);
      const chunk = obj ? eventText(obj) : (data.startsWith('{') ? '' : data);
      if (chunk) full = mergeText(full, chunk);
    };

    const line = (raw) => {
      const l = raw.replace(/\r$/, '');
      if (l === '') { dispatch(); return; }
      if (l.startsWith('data:')) dataLines.push(l.slice(5).replace(/^ /, ''));
    };

    try {
      while (!done) {
        const r = await reader.read();
        if (r.done) break;
        buf += dec.decode(r.value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const l = buf.slice(0, i);
          buf = buf.slice(i + 1);
          line(l);
        }
      }
      buf += dec.decode();
      if (buf) line(buf);
      dispatch();
      if (full.trim()) completeTurn(turnId, conv || info.conversationId, full, 'sse-fetch');
    } catch (e) {
      if (full.trim()) completeTurn(turnId, conv || info.conversationId, full, 'sse-fetch-partial');
      debug('sse-error', { error: String(e && e.message || e) });
    } finally {
      try { reader.releaseLock(); } catch (_) {}
    }
  }

  if (origFetch) {
    window.fetch = async function ecqFetch(input, init) {
      let url = '';
      let method = 'GET';
      try {
        if (typeof input === 'string') { url = input; method = (init && init.method) || 'GET'; }
        else if (input && typeof input === 'object' && input.url) { url = input.url; method = (init && init.method) || input.method || 'GET'; }
        url = absUrl(url);
        method = String(method || 'GET').toUpperCase();
        void probeFetchPost(input, init, url, method);
        if (isChatPost(url, method)) return await fetchChat(input, init, url, method);
        if (isAbort(url, method)) {
          const tid = lastTurnId;
          if (tid && turns.has(tid)) abortTurn(turns.get(tid));
        }
        const res = await origFetch(input, init);
        if (res && (res.status === 401 || res.status === 403)) void onAuthInvalid();
        if (isStatus(url, method)) void captureStatusResponse(res, url, 'status-fetch');
        if (isStreamGet(url, method)) void captureSse(res, url);
        return res;
      } catch (e) {
        throw e;
      }
    };
  }

  function xhrResponseText(xhr) {
    try {
      const rt = String((xhr && xhr.responseType) || '');
      if (rt && rt !== 'text') {
        const r = xhr && xhr.response;
        if (r == null) return '';
        if (typeof r === 'string') return r;
        try { return JSON.stringify(r); } catch (_) { return ''; }
      }
      return String((xhr && xhr.responseText) || '');
    } catch (_) { return ''; }
  }

  /* ---------------- XHR ---------------- */
  if (origXhrOpen && origXhrSend) {
    const XHR = window.XMLHttpRequest;
    XHR.prototype.open = function (method, url) {
      try {
        this.__ecqMethod = String(method || 'GET').toUpperCase();
        this.__ecqUrl = absUrl(url);
        this.__ecqAsync = arguments.length < 3 ? true : !!arguments[2];
      } catch (_) {}
      return origXhrOpen.apply(this, arguments);
    };
    XHR.prototype.send = function (body) {
      let sendBody = body;
      let pendingCtx = null;
      try {
        const xhr = this;
        const method = this.__ecqMethod || 'GET';
        const url = this.__ecqUrl || '';
        probePostBody(url, method, body, 'xhr');
        let chatInfo = null;
        if (isChatPost(url, method) && typeof body === 'string') {
          const obj = safeJson(body);
          if (obj && typeof obj === 'object') {
            const info = makeTurn({
              turnId: turnIdNew(),
              agentId: extractAgentId(obj, url) || AGENT_FALLBACK,
              agentName: extractAgentName(obj),
              userText: extractUserText(obj),
              conversationId: extractConversationId(obj, url),
              startedAt: now(),
              url,
              aborted: false,
              ctxBlock: ''
            });
            if (!info.userText) {
              debug('user-text-empty', {
                src: 'xhr',
                url: cut(url, 160),
                keys: safeKeys(obj, 24),
                preview: cut(redactedJson(obj), 500)
              });
            } else {
              reportRequest(info);
              const cached = getCachedContext(info.agentId, info.userText);
              if (cached && cached.block) {
                info.ctxBlock = cached.block;
                withMemoryBlock(obj, cached.block);
                sendBody = JSON.stringify(obj);
                debug('ctx-inject', { src: 'xhr', via: 'cache', agentId: info.agentId, chars: cached.block.length });
              } else if (xhr.__ecqAsync !== false) {
                pendingCtx = { info, original: body };
              } else {
                debug('ctx-skip', { src: 'xhr', reason: 'sync-xhr' });
              }
            }
            chatInfo = info;
          }
        }
        if (chatInfo) {
          const info = chatInfo;
          xhr.addEventListener('load', () => {
            const text = xhrResponseText(xhr);
            const obj = safeJson(text);
            if (obj) {
              noteNet('chat-post-xhr', 'POST', url, xhr.status, null, obj, true);
              const conv = extractConversationIdFromResponse(obj);
              if (conv) {
                info.conversationId = conv;
                convTurns.set(conv, info.turnId);
                reportRequest(info);
              }
              const reply = assistantFromObject(obj);
              if (reply) completeTurn(info.turnId, conv || info.conversationId, reply, 'post-xhr-json');
            } else {
              const sse = parseSseText(text);
              if (sse) completeTurn(info.turnId, info.conversationId, sse, 'post-xhr-sse');
            }
          });
        }
        if (isStatus(url, method)) {
          xhr.addEventListener('load', () => {
            const obj = safeJson(xhrResponseText(xhr));
            if (!obj) return;
            const m = url.match(/\/api\/agents\/chat\/status\/([^/?#]+)/);
            const conv = m ? decodeURIComponent(m[1]) : '';
            noteNet('status-xhr', 'GET', url, xhr.status, null, obj, true);
            captureStatusPayload(obj, conv, 'status-xhr');
          });
        }
        if (isStreamGet(url, method)) {
          const startedAt = now();
          xhr.__ecqStartedAt = startedAt;
          xhr.__ecqStreamRaw = '';
          let parsedFull = '';
          let finalized = false;
          const conv = (url.match(/\/stream\/([^/?#]+)/) || [])[1] || '';
          const absorb = () => {
            const text = xhrResponseText(xhr);
            if (!text) return;
            const prev = String(xhr.__ecqStreamRaw || '');
            if (text.length >= prev.length) xhr.__ecqStreamRaw = text;
            else if (!prev.includes(text)) xhr.__ecqStreamRaw = prev + text;
            const nowFull = parseSseText(xhr.__ecqStreamRaw);
            if (nowFull) parsedFull = mergeText(parsedFull, nowFull);
          };
          const finalize = (source) => {
            if (finalized) return;
            finalized = true;
            absorb();
            const text = parsedFull || parseSseText(xhr.__ecqStreamRaw || '');
            const tid = convTurns.get(conv) || lastTurnId || '';
            noteNet('stream-xhr', 'GET', url, xhr.status, null, null, true);
            if (text.trim()) {
              completeTurn(tid, conv, text, source);
              debug('xhr-sse-final', { conv: cut(conv, 120), chars: text.length, source, raw: String(xhr.__ecqStreamRaw || '').length });
            } else {
              debug('xhr-sse-empty', { conv: cut(conv, 120), status: xhr.status, ready: xhr.readyState, raw: String(xhr.__ecqStreamRaw || '').length, source });
            }
          };
          const onProgress = () => { absorb(); };
          xhr.addEventListener('progress', onProgress);
          xhr.addEventListener('readystatechange', () => {
            if (xhr.readyState >= 3) onProgress();
            if (xhr.readyState === 4) finalize('xhr-sse-end');
          });
          xhr.addEventListener('load', () => finalize('xhr-sse-load'));
          xhr.addEventListener('loadend', () => finalize('xhr-sse-loadend'));
          xhr.addEventListener('abort', () => finalize('xhr-sse-abort'));
          xhr.addEventListener('error', () => finalize('xhr-sse-error'));
          xhr.addEventListener('timeout', () => finalize('xhr-sse-timeout'));
        }
        if (pendingCtx) {
          const pc = pendingCtx;
          requestContext(pc.info.agentId, pc.info.agentName, pc.info.userText).then((ctx) => {
            let out = pc.original;
            if (ctx && ctx.block) {
              try {
                const copy = safeJson(pc.original);
                if (copy && typeof copy === 'object') {
                  withMemoryBlock(copy, ctx.block);
                  out = JSON.stringify(copy);
                  pc.info.ctxBlock = ctx.block;
                  debug('ctx-inject', { src: 'xhr', via: 'live', agentId: pc.info.agentId, chars: ctx.block.length });
                }
              } catch (e) {
                debug('ctx-inject-error', { error: String(e && e.message || e) });
              }
            } else {
              debug('ctx-empty', { src: 'xhr', agentId: pc.info.agentId });
            }
            try { origXhrSend.call(xhr, out); }
            catch (e) { debug('xhr-late-send-error', { error: String(e && e.message || e) }); }
          }).catch(() => {
            try { origXhrSend.call(xhr, pc.original); }
            catch (e) { debug('xhr-late-send-error', { error: String(e && e.message || e) }); }
          });
          return;
        }
      } catch (e) {
        debug('xhr-hook-error', { error: String(e && e.message || e) });
      }
      return origXhrSend.call(this, sendBody);
    };
  }

  /* ---------------- EventSource ---------------- */
  if (OrigES) {
    function WrappedES(url, config) {
      const es = new OrigES(url, config);
      try {
        const fullUrl = absUrl(url);
        const conv = (fullUrl.match(/\/stream\/([^/?#]+)/) || [])[1] || '';
        let full = '';
        let finished = false;
        const flush = (source) => {
          if (finished) return;
          finished = true;
          if (full.trim()) completeTurn(convTurns.get(conv) || lastTurnId, conv, full, source);
        };
        es.addEventListener('message', (ev) => {
          const data = String(ev.data || '').trim();
          if (!data) return;
          if (data === '[DONE]') { flush('eventsource'); return; }
          const obj = safeJson(data);
          const chunk = obj ? eventText(obj) : (data.startsWith('{') ? '' : data);
          if (chunk) full = mergeText(full, chunk);
        });
        es.addEventListener('error', () => flush('eventsource-error'));
        es.addEventListener('close', () => flush('eventsource-close'));
      } catch (e) {
        debug('es-hook-error', { error: String(e && e.message || e) });
      }
      return es;
    }
    WrappedES.prototype = OrigES.prototype;
    try { Object.setPrototypeOf(WrappedES, OrigES); } catch (_) {}
    window.EventSource = WrappedES;
  }

  /* ---------------- Auth ---------------- */
  function extractToken(obj) {
    if (!obj || typeof obj !== 'object') return '';
    return String(obj.token || obj.accessToken || obj.access_token ||
      (obj.data && (obj.data.token || obj.data.accessToken || obj.data.access_token)) || '');
  }

  async function onLoggedOut() {
    state.auth = null;
    clearContextCache();
    try { await rpc('logout', {}, 900); } catch (_) {}
    debug('auth-logged-out', {});
  }

  async function onAuthInvalid() {
    state.auth = null;
    clearContextCache();
    debug('auth-invalid', {});
  }

  async function refreshAuth(reason) {
    if (!origFetch) return null;
    try {
      const r = await origFetch('/api/auth/refresh', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: '{}'
      });
      if (r.status === 401 || r.status === 403) { await onLoggedOut(); return null; }
      if (!r.ok) return null;
      const j = await r.json().catch(() => null);
      const token = extractToken(j);
      if (!token) { await onLoggedOut(); return null; }
      const ur = await origFetch('/api/user', {
        credentials: 'include',
        headers: { Authorization: 'Bearer ' + token }
      });
      if (ur.status === 401 || ur.status === 403) { await onLoggedOut(); return null; }
      if (!ur.ok) return null;
      const uj = await ur.json().catch(() => null);
      const user = (uj && (uj.user || (uj.data && uj.data.user) || uj.data || uj)) || {};
      const accountId = String(user.id || user._id || user.userId || user.uid || '');
      const payload = {
        token,
        accountId,
        name: String(user.name || user.nickname || user.displayName || user.username || ''),
        username: String(user.username || ''),
        role: String(user.role || ''),
        at: now(),
        reason: reason || ''
      };
      const before = accountIdNow();
      state.auth = payload;
      if (before && before !== accountId) clearContextCache();
      post('auth', payload);
      debug('auth-ok', { accountId, reason });
      return payload;
    } catch (e) {
      debug('auth-error', { error: String(e && e.message || e), reason });
      return null;
    }
  }

  /* ---------------- init ---------------- */
  async function init() {
    const boot = window.__ECQ_MEM_BOOT__;
    if (boot) { boot.stage = 'init'; boot.at = Date.now(); }
    try {
      const st = await rpc('get-state', {}, 1600);
      if (st && st.ok) {
        state.identity = st.identity || null;
        state.settings = st.settings || null;
      }
    } catch (e) {
      if (boot) boot.err = String((e && e.message) || e);
    }
    state.ready = true;
    if (boot) { boot.stage = 'auth'; boot.at = Date.now(); }
    await refreshAuth('load');
    setInterval(() => { void refreshAuth('timer'); }, 10 * 60 * 1000);
    if (boot) { boot.stage = 'ready'; boot.at = Date.now(); }
    try { document.documentElement.dataset.ecqPage = '2-ready'; } catch (_) {}
    let frames = [];
    try { frames = Array.from(document.querySelectorAll('iframe')).map((f) => cut(String(f.src || ''), 160)).slice(0, 5); } catch (_) {}
    debug('page-ready', { url: location.href, mode: injectionMode(), isTop: window.top === window, frames });
  }

  void init();
})();
